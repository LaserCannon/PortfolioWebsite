///////////////////////////////////////
// **Splash.bhv.cs**
//   -Splash screen
//
//By Bryant Cannon
//20 April 2009
//////////////////////////////////////

if (!isObject(SplashBehavior))
{
   %template = new BehaviorTemplate(SplashBehavior);
   
   %template.friendlyName = "Splash";
   %template.behaviorType = "Other";
   %template.description  = "Object is the splash screen";
}

function SplashBehavior::onLevelLoaded(%this)
{
   //%this.owner.setImageMap(SplashScreenOrange_1280_800ImageMap);
   //%this.owner.setSize("128 80");
   //%this.owner.setPosition("0 0");
   %this.owner.setUseMouseEvents(true);
   %this.owner.setBlendColor(0,0,0,1);
   %this.owner.setVisible(true);
   schedule(2000,0,fadeColor,%this.owner,600,1,1,1,1);
   %this.schedule(6000,fadeOut);
}

function SplashBehavior::onMouseDown(%this)
{
   
}

function SplashBehavior::fadeOut(%this)
{
   fadeColor(%this.owner,400,0,0,0,0);
   //%this.owner.schedule(450,setImageMap,"Tutorial_Screen_" @ %this.set @ "ImageMap");
   %this.owner.schedule(600,setVisible,false);
   schedule(700,0,levelProgress,"game/data/levels/BiblicalLevel.t2d",false);
   //expandFilename($Game::DefaultScene);  //<--Finds "default" scene
}

/////////////////////////////////////
// **CharacterBhv**
//   -Gives general AI to a character
//
//By Bryant Cannon 
//3 February 2009
//////////////////////////////////////

//Constants
$MAX_FAITH = 100;
$MAX_LOVE = 100;
$MAX_HAP = 100;
$MAX_ANG = 100;
$MAX_APY = 100;
$MAX_EXT = 100;

$CHARACTER_SPEED = 8;
$PRAY_DURATION = 5000;              //Duration the "pray" action takes
$FULFILLED_BASE_DURATION = 45000;   //How long a fulfilment lasts
$FULFILLED_ADJUST_DURATION = 1960;   //Adjustment to above by expecation
$FULFILLED_BASE_QUESTION = 20000;   //How long the character takes to question unanswered prayers
$FULFILLED_ADJUST_QUESTION = 1000;  //Asjustment to above by expectation
$NEW_WALK_MIN = 1000;         //Time to reinstate walk after another walk (MIN)
$NEW_WALK_MAX = 4000;         // "     "       "   (MAX)
$NEW_WALK_ACT_MIN = 100;     //Time to reinstate walk after an action (MIN)
$NEW_WALK_ACT_MAX = 500;     // "     "        "   (MAX)

$MEM_COOL_DOWN = 3000;        //How long it takes for each tick of "forgetting" where char has been

$PRAY_TRIG_RATE = 18;      //Rate (1/n every allure attempt) to be triggered by alluring
$SIN_TRIG_RATE = 12;       //Rate (1/n every tempt attempt) to be triggered by temptation

if (!isObject(CharacterBhv))
{
   %template = new BehaviorTemplate(CharacterBhv);
   
   %template.friendlyName = "Character";
   %template.behaviorType = "Character";
   %template.description  = "Gives character attributes to an Object";
   
   //Add behavior field
   %template.addBehaviorField(charName, "Name of Character", string, "");
   %template.addBehaviorField(charPrf, "Animation profile name", string, "");
   %template.addBehaviorField(faith, "Initial 'Faith' amount (0-100)", int, 101);
   %template.addBehaviorField(love, "Initial 'Love' amount (0-100)", int, 101);
   %template.addBehaviorField(happiness, "Initial 'Happiness' amount (0-100)", int, 101);
   %template.addBehaviorField(anger, "Initial 'Anger' amount (0-100)", int, -1);
   %template.addBehaviorField(apathy, "Initial 'apathy' amount (0-100)", int, -1);
   %template.addBehaviorField(expectation, "Initial 'Expectation' amount (0-100)", int, -1);
   %template.addBehaviorField(shamed, "Character begins 'Shamed'", bool, false);
   %template.addBehaviorField(lifeSpan, "Time that character lives (in 1/1000 sec)", int, 200000);
   
   %faithfulness = "NONE" TAB "Devout" TAB "Skeptical";
   %sociality = "NONE" TAB "Intravert" TAB "Extravert";
   %materials = "NONE" TAB "Greedy" TAB "Attention" TAB "Prestige";
   %template.addBehaviorField(faithfulness, "Character's faithfulness", enum, "NONE", %faithfulness);
   %template.addBehaviorField(sociality, "Character's sociality", enum, "NONE", %sociality);
   %template.addBehaviorField(materialism, "Character's type of materialism", enum, "NONE", %materials);
   
   //Make sure list is set
   if(!isObject($charList)) {
      $charList = new SimSet(Characters);
   }
   $charSelect = "NULL";
   if(!isObject($deadList)) {
      $deadList = new SimSet(DeadCharacters);
   }
}

function CharacterBhv::onAddToScene(%this)
{
   //Add to global list
   Characters.add(%this.owner);
   
   //Set collision settings
   %this.owner.CollisionPhysicsSend = "0";
   %this.owner.CollisionPhysicsReceive = "0";
   %this.owner.CollisionActiveSend = "0";
   %this.owner.CollisionActiveReceive = "0";
   %this.owner.CollisionPolyList = "-0.500 -0.750 0.000 -0.850 0.500 -0.750 0.800 0.000 0.500 0.750 0.000 0.850 -0.500 0.750 -0.800 0.000";
   
   //Create pathfinding node list
   %this.searchedList = new SimSet();
   
   //Start "walking" loop/hello sexy i loves you :) --Morgen
   %this.walkEvent = %this.schedule(getRandom(1200,3000),findNewGoal);
   
   //Initialize character HUD (faith and love meters)
   MasterObject.initHUD(%this);
   
   %this.schedule(getRandom(2000,12000),addDesire,BlessingSet.getObject(getRandom(0,BlessingSet.getCount()-1)));
   
   //These variables are to keep the character from
   //  doing the same thing twice too often.
   %this.justDid = %this;        //Really a filler, just so its set to something
   %this.justDidShield = 0;
   %this.onWay = false;          //True if already commanded to "errand" to church
   
   //Assign appropriate animation sprite
   //%this.owner.setAnimation(%this.charPrf.idleDownAnim);
   
   //Schedule to die
   %this.lifeEvent = %this.schedule(%this.lifeSpan,endLife);
   
   %this.owner.enableUpdateCallback();
}

function CharacterBhv::onBehaviorAdd(%this)
{
   //Character object references
   %me = %this.owner;
   %this.owner.charBhv = %this;
   
   //Collision/Callback initialization
   %me.setUseMouseEvents(true);
   %me.enableUpdateCallback();
   %me.setCollisionCallback(true);
   
   //Display Initialization
   %me.setLayer(5);
   
   //Check character Variables for bound breaks
   %this.changeFaith(%this.faith,true);
   %this.changeLove(%this.love,true);
   %this.changeHAP(%this.happiness,true);
   %this.changeANG(%this.anger,true);
   %this.changeAPY(%this.apathy,true);
   %this.changeEXT(%this.expectation,true);
   
   //State variables
   %this.shieldEvent = "NULL";
   
   %me.goal = "NULL";
   %me.curWayp = "NULL";
   %me.curWayX = 0;
   %me.curWayY = 0;
   %this.waypFound = false;

   %me.free = true;
   %me.errand = false;
   %me.dead = false;
   %me.saved = false;
   
   %me.prayedForgiveness = false;
   
   %me.desires[0] = "NULL";
   %me.desires[1] = "NULL";
   %me.desires[2] = "NULL";
   %me.desirePrayed[0] = false;
   %me.desirePrayed[1] = false;
   %me.desirePrayed[2] = false;
   
   %me.fulfilled[0] = "NULL";
   %me.fulfilled[1] = "NULL";
   %me.fulfilled[2] = "NULL";
   
   %this.waypSpread = 2; //Number of waypoints not stopped at
}

function CharacterBhv::onUpdate(%this)
{
   //Go to church if it's Sunday past 9:00
   /*if (WeekTimer.getDay() $= "Sunday" && WeekTimer.getHour() >= 9)
   {
      //Cancel action and walk cycle
      %this.owner.setImageMap(CloudScaredAniImageMap);
      MasterObject.hidePrayerBubbles(%this);
      cancel(%this.walkEvent);
      
      //If character has enough faith and love, he goes to church.
      echo(%this.faith>=$Church.churchBhv.faithQuota SPC %this.love>=$Church.churchBhv.loveQuota SPC %this.onWay);
      if(%this.faith>=$Church.churchBhv.faithQuota && %this.love>=$Church.churchBhv.loveQuota && !%this.onWay)
      {
         $Church.filled+=1;
         %this.onWay = true;
         %this.setErrand($Church);
      }
   }*/
   
   //CURRENT ERROR: this code doesnt allow the user to pause the character
   /*if(isEventPending(%this.walkEvent) || !%this.isFree()) {
      %this.errWait = 0;
   }
   else {
      if(%this.errWait >= 3) {
         %this.walkEvent = %this.schedule(33,updateGoal);
         %this.errWait = 0;
         echo("-Walk Event Error; reinstating");
      }
      else {
         %this.errWait++;
      }
   }*/
}

function CharacterBhv::onMouseDown(%this)
{
   //Do everything a right mouse click would do
   sceneWindow2D.onRightMouseDown();
   
   if (true)  //TODO: if %this.isFree();
   {
      //End the other character's action if he's free
      if(isObject($charSelect) && $charSelect.charBhv.isFree() && $charSelect.getID()!=%this.owner)
      {
         MasterObject.hideName($charSelect.charBhv);
         MasterObject.hideLight();
         $charSelect.charBhv.endAction();
      }
      
      //Make this the selected character
      $charSelect = %this.owner;
      
      //Options appear
      MasterObject.displayOptions($charSelect);
      MasterObject.displayName(%this);
      MasterObject.displayLight(%this);
   }
}

function CharacterBhv::onMouseEnter(%this)
{
   //Exit if someone else is selected
   if(!isObject($charSelect) || $charSelect.getID()==%this.owner.getID()) { 
      MasterObject.displayLight(%this);
   }
   
   if(%this.owner.free && !%this.owner.errand)
   {
      //%this.owner.setAnimation(...);
      %this.pauseMovement();
   }
   if(!%this.praying) {
      MasterObject.displayPrayerBubbles(%this);
   }
   
   MasterObject.displayName(%this);
}

function CharacterBhv::onMouseLeave(%this)
{
   if(!isObject($charSelect) || $charSelect.getID()!=%this.owner.getID())
   {
      
      MasterObject.hideName(%this);
      if(!isObject($charSelect) || $charSelect.getID()==%this.owner.getID()) { 
         MasterObject.hideLight();
      }
      if(%this.owner.free && !%this.owner.errand)
      {
         %this.endAction();
      }
      if(!%this.praying) {
         MasterObject.shrinkPrayerBubbles(%this);
      }
   }
}

function CharacterBhv::onCollision(%this,%dstObj)
{
   //If the collided is a character, test for feasability of current position.
   /*if(isObject(%dstObj.charBhv))
   {
      %x = %this.owner.getPositionX();
      %y = %this.owner.getPositionY();
      %w = %this.owner.curWayp;
      %d = distance(%x,%y,%this.owner.curWayX,%this.owner.curWayY);
      if(%d<3.0 || (%x<%w.getPositionX()+%w.wayBhv.maxX && %x>%w.getPositionX()+%w.wayBhv.minX
                     && %y<%w.getPositionY()+%w.wayBhv.maxY && %y>%w.getPositionY()+%w.wayBhv.minY))
      {
         %this.pauseMovement();
         cancel(%this.walkEvent);
         %this.findNextWaypoint();
      }
   }*/
}


///////////////////////////////
//CUSTOM FUNCTIONS            /
///////////////////////////////

function CharacterBhv::onBlessed(%this,%blessPrf)
{
   %fth = 0; %lov = 0;
   %hap = 0; %ang = 0;
   %apy = 0; %exp = 0;
   
   //***BLESSING EFFECTS***
   //Faith
   %fth-=8;
   if (%this.faith<70) { %fth-=%this.expectation/10; }
   if (%this.apathy>50) { %fth-=(%this.apathy/10-5); }
   if (%this.faithfulness$="Devout") { %fth+=5; }
   //Love
   %lov+=10;
   //Happiness
   %hap+=15;
   //Anger
   %ang-=10;
   //Apathy
   //Expectation
   %exp+=4;
   
   //Adjustment for answered prayers
   for(%i=0;%i<3;%i++) {
      if (isObject(%this.owner.desires[%i]) && %this.owner.desires[%i].getID() == %blessPrf.getID())
      {
         //Faith adjustment if prayed for
         if(%this.owner.desirePrayed[%i]) {
            %fth+=20;
            %this.owner.desirePrayed[%i] = false;
            %t = newText("PrayAns","Prayer Answered!","Altenlisch MF",3,0,0,0,1);
            simpleFloatUpFade(%t,%this.owner.getPositionX(),%this.owner.getPositionY()+4,true);
         }
         else {
            %apy+=6;
         }
         //Set a fulfilled
         %this.addFulfilled(%blessPrf);
         //Get rid of the desire
         %this.owner.desires[%i] = "NULL";
         break;
      }
      
      if (%i == 2) { //If none were prayed for / desired
         %apy+=6;
      }
   }
   
   //Adjust for forgiveness
   if(%blessPrf.getID() == $forgive.getId())
   {
      %fth = 100;
      %lov += 50;
      %hap += 30;
      %ang = -100;
      %apy = -100;
      %exp += 40;
   }
   
   %this.changeFaith(mFloor(%fth));
   %this.changeLove(%lov);
   %this.changeHAP(%hap);
   %this.changeANG(%ang);
   %this.changeAPY(%apy);
   
   //Do Animation
   %x = %this.owner.getPositionX();
   %y = %this.owner.getPositionY();
   statChangeEffect("Faith",mFloor(%fth),%x-4,%y,"singleFloat");
   statChangeEffect("Love",%lov,%x+4,%y,"singleFloat");
   MasterObject.hidePrayerBubbles(%this);
   MasterObject.displayPrayerBubbles(%this);
   MasterObject.shrinkPrayerBubbles(%this);
   MasterObject.hideName(%this);
}

function CharacterBhv::onSign(%this,%signPrf)
{
   %fth = 0; %lov = 0;
   %hap = 0; %ang = 0;
   %apy = 0; %exp = 0;
   
   //***SIGN EFFECTS***
   //Faith
   %fth += mFloor(12-%this.apathy/10);
   //Love
   %lov += 3;
   //Happiness
   //Anger
   //Apathy
   %apy += 20;
   //Expectation
   
   %this.changeFaith(%fth);
   %this.changeLove(%lov);
   %this.changeAPY(%apy);
   
   //Do Animation
   %x = %this.owner.getPositionX();
   %y = %this.owner.getPositionY();
   statChangeEffect("Faith",%fth,%x-4,%y,"singleFloat");  
   statChangeEffect("Love",%lov,%x+4,%y,"singleFloat");
   MasterObject.hideName(%this);
}

function CharacterBhv::onSmite(%this,%smitePrf)
{
   %fth = 0; %lov = 0;
   %hap = 0; %ang = 0;
   %apy = 0; %exp = 0;
   
   //***SMITE EFFECTS***
   //Faith
   %fth+=mFloor(15-%this.anger/20);
   //Love
   %lov-=mFloor(12+%this.anger/10);
   //Happiness
   %this.changeHAP(-10);
   //Anger
   %this.changeANG(15);
   //Apathy
   %this.changeAPY(-10);
   //Expectation
   
   %this.changeFaith(%fth);
   %this.changeLove(%lov);
   
   //Do Animation
   %x = %this.owner.getPositionX();
   %y = %this.owner.getPositionY();
   statChangeEffect("Faith",%fth,%x-4,%y,"singleFloat");  
   statChangeEffect("Love",%lov,%x+4,%y,"singleFloat");
   MasterObject.hideName(%this);
}

function CharacterBhv::roleSin(%this,%temptVal,%temptTrigg)
{
   //First, exit if the character it already busy
   if (%this.isFree() == false) { return; }
   
   //If character is "shamed," increase the odds
   if (%this.owner.shamed == true)
   {
      %temptVal += 3;
   }
   
   //Chance to sin
   if(getRandom(0,$SIN_TRIG_RATE)+(%this.faith+%this.love)/40 <= %temptVal || 
            getRandom(0,20) < %this.apathy || %this.owner.goal.getID()==%temptTrigg.getID()) {
      //Defer sin if sin just happened
      if(%this.justDid==%temptTrigg && getRandom(0,%this.justDidShield*2)!=0) {
         //Deferred sin
      }
      else {
         echo("Sin!");
         %this.sin(%temptTrigg);
         %temptTrigg.sinBhv.sinPrf.sin(%this);
      }
   }
   else {
      //Put any animations/processing here
      // INCLUDING begin/end action
   }
}

function CharacterBhv::sin(%this,%sinTrigger)
{
   %fth = 0; %lov = 0;
   %hap = 0; %ang = 0;
   %apy = 0; %exp = 0;
   
   //***SIN EFFECTS***
   //Faith
   %fth -= 10;
   if (%this.shamed == true) { %fth-=5; }
   //Love
   %lov -= 10;
   if (%this.shamed == true) { %lov-=5; }
   //Happiness
   %hap -= 10;
   if (%this.shamed == true) { %hap+=10; }
   //Anger
   //Apathy
   //Expectation
   
   %this.changeFaith(%fth);
   %this.changeLove(%lov);
   %this.changeHAP(%hap);
   
   
   //Chance to become shamed
   if (getRandom(0,10) < %sinTrigger.sinBhv.shameRand)
   {
      %this.shamed = true;
   }
   
   //Do Animation
   //%this.beginAction();
   %x = %this.owner.getPositionX();
   %y = %this.owner.getPositionY();
   //%this.owner.setimageMap(CloudAngryAniImageMap);
   statChangeEffect("Faith",%fth,%x-4,%y,"singleFloat");  
   statChangeEffect("Love",%lov,%x+4,%y,"singleFloat");
   /*%msg = newText("txt","SIN","Arial",6,1,0.3,0,1);
   %msg.setPosition(%x-3 SPC %y+4);
   %msg.setVisible(true);
   schedule(1000,0,fadeAlpha,%msg,1000,0.0);
   %msg.schedule(3000,delete);*/
   //%this.schedule(1000,endAction);
   for(%i=0;%i<3;%i++) {
      if(isObject(%this.owner.desires[%i]) && %sinTrigger.sinBhv.sinPrf.blessAssociate.getID()==%this.owner.desires[%i].getID()) {
         %this.owner.desires[%i] = "NULL";
         %this.owner.desirePrayed[%i] = false;
         MasterObject.hidePrayerBubbles(%this);
         MasterObject.displayPrayerBubbles(%this);
         MasterObject.shrinkPrayerBubbles(%this);
         break;
      }
   }
   
   //Tell the memory that this was just done so that it doesnt happen too soon
   if(%this.justDid.getId() != %sinTrigger.getId())
   {
      %this.justDidShield = 0;
   }   
   %this.justDid = %sinTrigger;
   %this.justDidShield += 10;
   if (!isEventPending(%this.shieldEvent)) {
      %this.shieldEvent = %this.schedule($MEM_COOL_DOWN,memShieldMinus);
   }
   
   //Find a new goal
   %this.findNewGoal();
}

function CharacterBhv::rolePray(%this,%prayTrigg)
{
   //First, exit if the character it already busy
   if (%this.isFree() == false || %this.getNumDesires() == 0) { return; }
   
   //Calculate role add
   %add = 10-%this.faith/10;
   if(%this.faith<35 && %this.happiness > 50)
   {
      %add+=(%this.happiness/10-5);
   }
   
   if(getRandom(0,$PRAY_TRIG_RATE)+%add <= 7 || %this.owner.goal.getID()==%prayTrigg.getID()) {
      if(!isEventPending(%this.fulfillCheckEvent)) {
         %this.pray();
      }
   }
   else {
      //Put any animations/processing here
   }
   
}

function CharacterBhv::pray(%this)
{
   //First, exit if the character it already busy
   if (%this.isFree() == false) { return; }
   
   //Begin action by dropping all other tasks, etc.
   %this.beginAction();
   %this.praying = true;
   
   //End prayer in a little while
   %this.schedule($PRAY_DURATION,endAction);
   
   //Make sure it doesn't happen very soon
   //TO DO - make reference to prayer trigger... do for sins too!
   
   //Change image
   %this.owner.setAnimation(%this.charPrf.prayerAnim);
   
   //Set "prayed for" for all desires
   for(%i=0;%i<3;%i++)
   {
      if(isObject(%this.owner.desires[%i])) {
         %this.owner.desirePrayed[%i] = true;
      }
   }
   
   //Show thought bubbles
   MasterObject.displayPrayerBubbles(%this);
   
   //If shamed, pray also for forgiveness (under certain conditions)
   if(%this.shamed == true) {
      if(%this.faith > 30) {
         MasterObject.displayForgiveBubble(%this);
         %this.owner.prayedForgiveness = true;
      }
   }
   
   //***PRAYER EFFECTS***
   //Faith
   //Love
   //Happiness
   //Anger
   %this.changeANG(-10);
   //apathy
   //Epectation
   //DELAYED effects
   %this.fulfillCheckEvent = %this.schedule($FULFILLED_BASE_QUESTION-%this.expectation*$FULFILLED_ADJUST_QUESTION,checkFulfilled);
}

function CharacterBhv::checkFulfilled(%this)
{
   //See if any desires were fulfilled
   //OLD CODE
   /*for(%i=0;%i<3;%i++) {
      for(%j=0;%j<%this.numFulfilled;%j++) {
         if(%this.desires[%i] == %this.fulfilled[%j])
         {
            //If one is found, return true
            %this.desires[%i] = "NULL";
            return true;
         }
      }
   }*/
   
   //NEW: just see how many "fulfilled" are on the queue
   if (%this.expectation<70 && %this.getNumFulfilled()>=1) { return true; }
   else if (%this.getNumFulfilled()>=2)                   { return true; }
   
   //***If not, adjust stats accordingly and return false
   //Faith
   %this.changeFaith(0-%this.expectation/10,false);
   //Love
   %this.changeLove(0-%this.expectation/10,false);
   //Happiness
   //Anger
   %this.changeANG(10+%this.expectation/10,false);
   //apathy
   if (%this.apathy<50) { %this.changeAPY(-10,false); }
   //Expectation
   %this.changeEXT(-10,false);
   
   return false;
}

function CharacterBhv::addDesire(%this,%add)
{
   //TEMPORARY CODE, TO DO: CHANGE LATER!
   %this.schedule(30000,addDesire,BlessingSet.getObject(getRandom(0,BlessingSet.getCount()-1)));
   
   %ind = -1;
   for(%i=0;%i<3;%i++)
   {
      //Continue if desire doesnt exist
      if(isObject(%this.owner.desires[%i])) {
         //If the desire is already there, quit function
         if(%this.owner.desires[%i].getID() == %add.getID())
         {
            return false;
         }
      }
      //If there is no object in this slot, set this slot as "it"
      else
      {
         %ind = %i;
      }
   }
   //Add the desire
   if (%ind != -1) {
      %this.owner.desires[%ind] = %add;
      %this.owner.desirePrayed[%ind] = false;
      return true;
   }
   else { return false; }
}

function CharacterBhv::addFulfilled(%this,%add)
{
   %ind = -1;
   for(%i=0;%i<3;%i++)
   {
      //Continue if fulfilled doesnt exist
      if(isObject(%this.owner.fulfilled[%i]))
      {
         //If the fulfilled is already there, quit function
         if(%this.owner.fulfilled[%i].getID() == %add.getID())
         {
            return false;
         }
      }
      else 
      {
         %ind = %i;
      }
   }
   if (%ind != -1) {
      //Add the fulfilled
      %this.owner.fulfilled[%ind] = %add;
      //schedule to remove it after some time
      %this.schedule($FULFILLED_BASE_DURATION-$FULFILLED_ADJUST_DURATION*%this.expectation,removeFulfilled,%ind);
      return true;
   }
   else { return false; }
}

function CharacterBhv::removeFulfilled(%this,%ind)
{
   //Remove the fulfilment at %ind
   if(isObject(%this.owner.fulfilled[%ind]))
   {
      %this.owner.fulfilled[%ind] = "NULL";
   }
}


/////////////////////////
// PATHFINDING 
////////////////////////

function CharacterBhv::beginAction(%this)
{
   //Cancel walking and character is now "busy"
   %this.setFree(false);
   %this.pauseMovement();
}

function CharacterBhv::pauseMovement(%this)
{
   //Cancel walking, but character isn't "busy" ... USE endAction() TO REVERT BACK
   cancel(%this.walkEvent);
   %ang = getWord(%this.owner.getLinearVelocityPolar(),0);
   %this.owner.setLinearVelocityPolar(0,0);
   
   //Find correct idle animation
   %this.findAnimation(%ang,false);
}

function CharacterBhv::endAction(%this)
{
   //Reset business variables and image maps
   //%this.owner.setAnimation();
   MasterObject.shrinkPrayerBubbles(%this);
   %this.setFree(true);
   %this.owner.errand = false;
   %this.praying = false;
   if(isObject($charSelect) && $charSelect.getID()==%this.owner.getID() && !MasterObject.optionsUp)
   {
      $charSelect = "NULL";
   }
   
   //Pause to correct animation
   %this.pauseMovement();
   
   
   
   if(!isObject($charSelect) || $charSelect.getID()!=%this.owner.getID() || !MasterObject.optionsUp)
   {
      //Make sure walk cycle is back
      %this.walkEvent = %this.schedule(getRandom($NEW_WALK_ACT_MIN,$NEW_WALK_ACT_MAX),updateGoal);
   }
}

function CharacterBhv::setErrand(%this,%goto)
{
   //Where to go next
   %this.owner.goal = %goto;
   
   %this.owner.errand = true;

   //Start the updateGoal loop
   cancel(%this.walkEvent);
   %this.walkEvent = %this.schedule(33,updateGoal);
}

function CharacterBhv::setCurWaypoint(%this, %wayp)
{
   %this.owner.curWayp = %wayp;
   
   //If the waypoint is a trigger, set offsets to 3
   /*if (isObject(%wayp.wayBhv))
   {
      %this.owner.curWayX = %wayp.getPositionX()+getRandom(-3,3);
      %this.owner.curWayY = %wayp.getPositionY()+getRandom(-3,3);
   }*/
   
   //If its an actual waypoint, use its min and max values
   %this.owner.curWayX = %wayp.getPositionX()+getRandom(%wayp.wayBhv.minX,%wayp.wayBhv.maxX);
   %this.owner.curWayY = %wayp.getPositionY()+getRandom(%wayp.wayBhv.minY,%wayp.wayBhv.maxY);
}

function CharacterBhv::findNextWaypoint(%this)
{
   %this.waypFound = false;
   
   //If there is no waypoint, assign one
   if(!isObject(%this.owner.curWayp))
   {
      %d = 10000;
      %n = -1;
      
      //Loop through all waypoints
      for(%i=0;%i<Waypoints.getCount();%i++)
      {
         //Find the distance to object %i
         %wayp = Waypoints.getObject(%i);
         %x = %wayp.getPositionX() - %this.owner.getPositionX();
         %y = %wayp.getPositionY() - %this.owner.getPositionY();
         %newd = mSqrt(mPow(%x,2)+mPow(%y,2));
         
         //Distance comparison
         if (%newd < %d)
         {
            %n = %i;
            %d = %newd;
         }
      }
      //Exit if waypoints are empty
      if (%n == -1) { error("AI FAILURE"); return false; }
      
      //Assign the new waypoint
      %this.setCurWaypoint(Waypoints.getObject(%n));
   }
   
   //Make sure a goal exists and is NOT the current goal
   if(!isObject(%this.owner.goal) || %this.owner.goal.getID()==%this.owner.curWayp.getID())
   {
      %this.walkEvent = %this.schedule(getRandom($NEW_WALK_MIN,$NEW_WALK_MAX),findNewGoal);
      return;
   }
   
   /*/Save locations of current waypoint (to find distance between the two later)
   %x1 = %this.owner.curWayp.getPositionX();
   %y1 = %this.owner.curWayp.getPositionY();*/
   
   //Set the NEXT waypoint
   %this.searchNextWaypoint(0,%this.owner.curWayp,"NULL");
   
   /*/Find the distance between the two waypoints
   %x = %x1 - %this.owner.getPositionX();
   %y = %y1 - %this.owner.getPositionY();
   %this.waypSpread = mSqrt(mPow(%x,2)+mPow(%y,2));*/
   
   //Resume movement
   if(!isEventPending(%this.walkEvent)) {
      %this.walkEvent = %this.schedule(33,updateGoal);
   }
}

//UTILITY ONLY... ONLY CALL FROM findNextWaypoint()!!!
function CharacterBhv::searchNextWaypoint(%this,%depth,%wayp,%first)
{
   //Add this node to the searched list
   %this.searchedList.add(%wayp.getID());
   
   //Check to see if goal has been found yet
   if(%this.waypFound) { 
      %this.searchedList.clear();
      return false;
   }
   
   //Set "first" if it's currently not set to a waypoint
   if(%first$="ROOT") {
      %first = %wayp;
   }
   if(%first$="NULL") {
      %first = "ROOT";
   }
   
   for(%i=0;%i<%wayp.connects.getCount();%i++)
   {
      //Set the test subject
      %test = %wayp.connects.getObject(%i);
      
      //First, test to see if it was already visited
      if(%this.searchedList.isMember(%test.getID())) { continue; }
      
      //See if the goal is found
      if(%test.getID() == %this.owner.goal.getID())
      {
         //Change flag and clear list of searched nodes
         %this.waypFound = true;
         %this.searchedList.clear();
         //If depth is zero, return new waypoint
         if(%first$="ROOT") {
            %this.setCurWaypoint(%test);
            return;
         }
         //Return true if goal is found
         %this.setCurWaypoint(%first);
      }
      else
      {
         //If the goal is not found, create a new search thread
         %depth++;
         %this.schedule(getRandom(1,3),searchNextWaypoint,%depth,%test,%first);
      }
   }
}
//-     -     -     -     -     -      -      -     -

function CharacterBhv::findTriggerToSatisfy(%this)
{
   //Pick a random desire to satisfy
   %n = getRandom(0,%this.getNumDesires()-1);
   
   //Loop through sin points and consider appeal of each
   %allure = 0;
   %choice = "NULL";
   for(%i=0;%i<SinTriggers.getCount();%i++)
   {
      %x = 0;
      if(isObject(%this.getDesire(%n,true)) && SinTriggers.getObject(%i).sinBhv.sinPrf.blessAssociate.getID()==%this.getDesire(%n,true).getID())
      {
         %x = getRandom(0,100-%this.faith);
         %x2 = getRandom(%this.anger-60,%this.anger-20);
         if(%x2>%x) { %x = %x2; }
      } else {
         %x = getRandom(0,50-%this.faith/2);
      }
      if(%x>=%allure)
      {
         %allure = %x;
         %choice = SinTriggers.getObject(%i);
      }
   }
   
   //Loop through prayer points and consider appeal of closest one
   %low = 100000;
   %p = "NULL";
   for(%i=0;%i<PrayTriggers.getCount();%i++)
   {
      %d = objDistance(PrayTriggers.getObject(%i),%this.owner);
      if(%d<%low)
      {
         %low = %d;
         %p = PrayTriggers.getObject(%i);
      }
   }
   
   //Consider prayer(with curve adjustment) vs. sin
   //%y = mSqrt(getRandom(0,%this.faith)/100)*100;
   %y = getRandom(0,%this.faith);
   if(isObject(%p) && %y>=%allure)
   {
      %choice = %p;
   }
   
   //Echo and return choice
   echo(%this.charName @ "'s choice: " @ %choice.getID() SPC %choice.getName());
   return %choice;
}

function CharacterBhv::findNewGoal(%this)
{
   //Figure out where to go next
   %g = %this.findTriggerToSatisfy();
   
   //Set goal
   %this.setNewGoal(%g);
   
   //Reinstate waypoint searching
   %this.findNextWaypoint();
}

function CharacterBhv::setNewGoal(%this,%goal)
{
   //Set goal
   %this.owner.goal = %goal;
   
   //Make sure errand is NOT true
   %this.owner.errand = false;
   
}

function CharacterBhv::findAnimation(%this,%ang,%walk)
{
   if(%walk) {
      //Find correct movement animation
      if(%ang>=45 && %ang<135) { %anim = %this.charPrf.rightAnim; }
      else if(%ang>=135 || %ang<-135) { %anim = %this.charPrf.downAnim; }
      else if(%ang>=-135 && %ang<-45) { %anim = %this.charPrf.leftAnim; }
      else if(%ang>=-45 && %ang<45) { %anim = %this.charPrf.upAnim; }
      if(!isObject(%anim)) { //If %anim doesn't exist, use 4 diagonal quadrants
         if(%ang>=-90 && %ang<0) { %Danim = %this.charPrf.upLeftAnim; }
         else if(%ang>=0 && %ang<90) { %Danim = %this.charPrf.upRightAnim; }
         else if(%ang>=90) { %Danim = %this.charPrf.downRightAnim; }
         else if(%ang<-90) { %Danim = %this.charPrf.downLeftAnim; }
      } else {             //If %anim worked, only use 4 octants
         if(%ang>=-67 && %ang<-23) { %Danim = %this.charPrf.upLeftAnim; }
         else if(%ang>=23 && %ang<67) { %Danim = %this.charPrf.upRightAnim; }
         else if(%ang>=113 && %ang<157) { %Danim = %this.charPrf.downRightAnim; }
         else if(%ang>=-157 && %ang<-113) { %Danim = %this.charPrf.downLeftAnim; }
      }
   }
   else {
      //Find correct idle animation
      if(%ang>=45 && %ang<135) { %anim = %this.charPrf.idleRightAnim; }
      else if(%ang>=135 || %ang<-135) { %anim = %this.charPrf.idleDownAnim; }
      else if(%ang>=-135 && %ang<-45) { %anim = %this.charPrf.idleLeftAnim; }
      else if(%ang>=-45 && %ang<45) { %anim = %this.charPrf.idleUpAnim; }
      if(!isObject(%anim)) { //If %anim doesn't exist, use 4 diagonal quadrants
         if(%ang>=-90 && %ang<0) { %Danim = %this.charPrf.idleUpLeftAnim; }
         else if(%ang>=0 && %ang<90) { %Danim = %this.charPrf.idleUpRightAnim; }
         else if(%ang>=90) { %Danim = %this.charPrf.idleDownRightAnim; }
         else if(%ang<-90) { %Danim = %this.charPrf.idleDownLeftAnim; }
      } else {             //If %anim worked, only use 4 octants
         if(%ang>=-67 && %ang<-23) { %Danim = %this.charPrf.idleUpLeftAnim; }
         else if(%ang>=23 && %ang<67) { %Danim = %this.charPrf.idleUpRightAnim; }
         else if(%ang>=113 && %ang<157) { %Danim = %this.charPrf.idleDownRightAnim; }
         else if(%ang>=-157 && %ang<-113) { %Danim = %this.charPrf.idleDownLeftAnim; }
      }
   }
   
   //Set correct animation if not already...
   if(isObject(%Danim)) {
      if(%this.owner.getAnimation().getID() != %Danim.getID()) {
         %this.owner.setAnimation(%Danim);
      }
   } else if(isObject(%anim)) {
      if(%this.owner.getAnimation().getID() != %anim.getID()) {
         %this.owner.setAnimation(%anim);
      }
   }
}

function CharacterBhv::updateGoal(%this)
{
   if($TutOn) {
      %this.walkEvent = %this.schedule(33,updateGoal);
      return;
   }
   
   //If dead, fly up
   if(%this.owner.dead)
   {
      %difx = -45 + %this.deadIndex*5 - %this.owner.getPositionX();
      %dify = -35 - %this.owner.getPositionY();
      
      if(mAbs(%difx)<0.5 && mAbs(%dify)<0.5) {
         %this.floatMsr = 0;
         %this.floatDir = 1;
         %this.float();
         %this.owner.floating = true;
         
         //Check for win
         %saved = 0;
         for(%i=0;%i<DeadCharacters.getCount();%i++) {
            if(DeadCharacters.getObject(%i).saved) { %saved++; }
         }
         if(!$won && DeadCharacters.getCount()==Characters.getCount())
         {
            fadeAlpha($veil,3000,1.0);
            %win = newText(WinText,"You saved " @ %saved @ " souls.", "Altenglisch MF",8,1,1,1,0);
            %win.setPosition("0 -3");
            schedule(3000,0,fadeAlpha,%win,2000,1.0);
            $won=true;
         }
         return;
      }
      
      //Get angle of movement
      %ang = mRadToDeg(mAtan(%difx,-%dify));
      //Set speed towards goal
      %this.owner.setLinearVelocityPolar(%ang,$CHARACTER_SPEED);
      
      %this.walkEvent = %this.schedule(33,updateGoal);
      return;
   }
   
   //First, if busy, stop walking.
   if(!%this.owner.free && !%this.owner.errand)
   {
      %this.owner.setLinearVelocityPolar(mRadToDeg(0),0);
      return;
   }
   
   //Get distance to waypoint
   %difx = %this.owner.curWayX - %this.owner.getPositionX();
   %dify = %this.owner.curWayY - %this.owner.getPositionY();

   //Constantly move towards the goal, slightly randomize when to stop
   if(mAbs(%difx)>=0.5 || mAbs(%dify)>=0.5)
   {
         //Get angle of movement
         %ang = mRadToDeg(mAtan(%difx,-%dify));
         //Set speed towards goal
         %this.owner.setLinearVelocityPolar(%ang,$CHARACTER_SPEED);
         //Call updateGoal again
         %this.walkEvent = %this.schedule(33,updateGoal);
         //Set animation
         %this.findAnimation(%ang,true);
   }
   else
   {
      //Stop character, start journey to new waypoint after a bit of time.
      %this.pauseMovement();
      if(%this.owner.free) {
         //Schedule goal search if at goal, waypoint search otherwise
         if(!isObject(%this.owner.goal) || %this.owner.curWayp.getID()==%this.owner.goal.getID()) {
            if(!isEventPending(%this.walkEvent) && !%this.owner.errand) {
               %this.walkEvent = %this.schedule(getRandom($NEW_WALK_MIN,$NEW_WALK_MAX),findNewGoal);
            }
            %this.waypSpread = 0;
         } else {
            //Set wait time: Chance to wait longer is increased if less waypoints wer visited
            if(!isEventPending(%this.walkEvent)) {
               if(%this.owner.errand || getRandom(0,%this.waypSpread) == 0) {
                  %wait = 10;
                  %this.waypSpread++;
               } else {
                  %wait = getRandom($NEW_WALK_MIN,$NEW_WALK_MAX);
                  %this.waypSpread = 0;
               }
               %this.walkEvent = %this.schedule(%wait,findNextWaypoint);
            }
         }
      }
   }
}

function CharacterBhv::float(%this)
{
   if(%this.floatDir==true)
   {
      if(%this.floatMsr>=4.0) {
         %this.floatDir=false;
         %this.floatMsr-=0.3;
      } else {
         %this.floatMsr+=0.3;
      }
   }
   else
   {
      if(%this.floatMsr<=-4.0) {
         %this.floatDir=true;
         %this.floatMsr+=0.3;
      } else {
         %this.floatMsr-=0.3;
      }
   }
   
   %this.owner.setLinearVelocityY(%this.floatMsr);
   %this.owner.setLinearVelocityX(0);
   
   %this.schedule(33,float);
}

function CharacterBhv::endLife(%this)
{
   if(%this.owner.free) {
      //Cancel action and walk cycle
      %this.deadIndex = DeadCharacters.getCount();
      DeadCharacters.add(%this.owner);
      %this.owner.setUseMouseEvents(false);
      %this.endAction();
      MasterObject.hidePrayerBubbles(%this);
      MasterObject.hideName(%this);
      if($charSelect == %this.owner) {
         MasterObject.hideOptions();
         $charSelect = "NULL";
         MasterObject.hideLight();
      }
      %this.faithMeter.delete();
      %this.loveMeter.delete();
      %this.angerMeter.delete();
      %this.shameSprite.delete();
      //%this.interactiveBubble.delete();
      %this.owner.setLinearVelocityPolar(0,0);
      %this.setFree(false);
      %this.owner.dead = true;
      cancel(%this.walkEvent);
   
      //Show angel if saved
      if(%this.owner.saved) {
         %this.owner.setAnimation(%this.charPrf.ghostRightAnim);
         %this.owner.setBlendAlpha(0.6);
         %this.walkEvent = %this.updateGoal();
      }
      else
      {
         %this.owner.setAnimation(Gravestone4Animation);
      }
      
   } else {
      %this.schedule(33,endLife);
   }
}


////////////////////////////////////
//SIMPLE ACCESSOR/MUTATOR FUNCTIONS/
////////////////////////////////////

function CharacterBhv::addLife(%this,%amt)
{
   if(isEventPending(%this.lifeEvent))
   {
      %time = getEventTimeLeft(%this.lifeEvent);
      cancel(%this.lifeEvent);
      %this.lifeEvent = %this.schedule(%time+%amt,endLife);
   }
}

function CharacterBhv::memShieldMinus(%this)
{
   %this.justDidShield -= 1;
   if (%this.justDidShield > 0 && !isEventPending(%this.shieldEvent)) {
      %this.shieldEvent = %this.schedule($MEM_COOL_DOWN,memShieldMinus);
   }
}

function CharacterBhv::getNumDesires(%this)
{
   %count = 0;
   if (isObject(%this.owner.desires[0])) { %count++; }
   if (isObject(%this.owner.desires[1])) { %count++; }
   if (isObject(%this.owner.desires[2])) { %count++; }
   return %count;
}

function CharacterBhv::getNumPrayedFor(%this)
{
   %count = 0;
   if (isObject(%this.owner.desires[0]) && %this.owner.desirePrayed[0]) { %count++; }
   if (isObject(%this.owner.desires[1]) && %this.owner.desirePrayed[1]) { %count++; }
   if (isObject(%this.owner.desires[2]) && %this.owner.desirePrayed[2]) { %count++; }
   return %count;
}

function CharacterBhv::getNumFulfilled(%this)
{
   %count = 0;
   if (isObject(%this.owner.fulfilled[0])) { %count++; }
   if (isObject(%this.owner.fulfilled[1])) { %count++; }
   if (isObject(%this.owner.fulfilled[2])) { %count++; }
   return %count;
}

function CharacterBhv::getDesire(%this,%num,%handle)
{
   for(%i=0;%i<3;%i++)
   {
      if(isObject(%this.owner.desires[%i])) {
         if (%num == 0) {
            //If the user wants the HANDLE of the desire object...
            if (%handle == true) {
               //..Return the handle.
               return %this.owner.desires[%i];
            } else {
               //Otherwise, return the index.
               return %i;
            }
         }
         else {
            %num--;
         }
      }
   }
   return -1;
}

function CharacterBhv::getDesirePrayed(%this,%num,%handle)
{
   for(%i=0;%i<3;%i++)
   {
      if(isObject(%this.owner.desires[%i]) && %this.owner.desirePrayed[%i]) {
         if (%num == 0) {
            //If the user wants the HANDLE of the desire object...
            if (%handle == true) {
               //..Return the handle.
               return %this.owner.desires[%i];
            } else {
               //Otherwise, return the index.
               return %i;
            }
         }
         else {
            %num--;
         }
      }
   }
   return -1;
}

function CharacterBhv::isDesired(%this,%desire)
{
   for(%i=0;%i<3;%i++) {
      if(%this.owner.desires[%i].getID()==%desire.getID())
      {
         return true;
      }
   }
   return false;
}

function CharacterBhv::setFree(%this,%setfree)
{
   %this.owner.free = %setfree;
}

function CharacterBhv::isFree(%this)
{
   return %this.owner.free;
}

function CharacterBhv::changeFaith(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.faith += %val; }
   else                 { %this.faith = %val; }
   if (%this.faith > $MAX_FAITH)  {%this.faith = $MAX_FAITH;}
   if (%this.faith < 0)    {%this.faith = 0;}
}

function CharacterBhv::changeLove(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.love += %val; }
   else                 { %this.love = %val; }
   if (%this.love > $MAX_LOVE)  {%this.love = $MAX_LOVE;}
   if (%this.love < 0)    {%this.love = 0;}
}

function CharacterBhv::changeHAP(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.happiness += %val; }
   else                 { %this.happiness = %val; }
   if (%this.happiness > $MAX_HAP)  {%this.happiness = $MAX_HAP;}
   if (%this.happiness < 0)    {%this.happiness = 0;}
}

function CharacterBhv::changeANG(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.anger += %val; }
   else                 { %this.anger = %val; }
   if (%this.anger > $MAX_ANG)  {%this.anger = $MAX_ANG;}
   if (%this.anger < 0)    {%this.anger = 0;}
}

function CharacterBhv::changeAPY(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.apathy += %val; }
   else                 { %this.apathy = %val; }
   if (%this.apathy > $MAX_APY)  {%this.apathy = $MAX_APY;}
   if (%this.apathy < 0)    {%this.apathy = 0;}
}

function CharacterBhv::changeEXT(%this,%val,%setAt)
{
   if (%setAt==false)   { %this.expectation += %val; }
   else                 { %this.expectation = %val; }
   if (%this.expectation > $MAX_EXT)  {%this.expectation = $MAX_EXT;}
   if (%this.expectation < 0)    {%this.expectation = 0;}
}



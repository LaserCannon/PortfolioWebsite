///////////////////////////////////////
// **LevelVeil.bhv.cs**
//   -Fades from black into level
//
//By Bryant Cannon
//21 April 2009
//////////////////////////////////////


if (!isObject(LevelVeilBehavior))
{
   %template = new BehaviorTemplate(LevelVeilBehavior);
   
   %template.friendlyName = "LevelVeil";
   %template.behaviorType = "Other";
   %template.description  = "Object fades away at start of level";
   
   %template.addBehaviorField(duration, "Suration of fade", float, 1000);
}

function LevelVeilBehavior::onLevelLoaded(%this)
{
   schedule(1400,0,fadeAlpha,%this.owner,%this.duration,0.0);
   //%this.owner.schedule(%this.duration+3000,safeDelete);
   $veil = %this.owner;
}

function LevelVeilBehavior::onBehaviorAdd(%this)
{
   //%this.owner.setBlendAlpha(0);
}

function LevelVeilBehavior::onAddToScene(%this)
{
   %this.owner.setPosition("0 0");
   %this.owner.setSize("128 80");
   %this.owner.setBlendAlpha(1);
}

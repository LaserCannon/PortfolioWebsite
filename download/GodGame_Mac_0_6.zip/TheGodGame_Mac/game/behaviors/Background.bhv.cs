///////////////////////////////////////
// **Background.bhv.cs**
//   -Background behaviors will facilitate clicking
//    on the game window
//
//By Bryant Cannon
//13 February 2009
//////////////////////////////////////

if (!isObject(BackgroundBehavior))
{
   %template = new BehaviorTemplate(BackgroundBehavior);
   
   %template.friendlyName = "Background";
   %template.behaviorType = "Other";
   %template.description  = "Object is the main background to the scene";
}

function BackgroundBehavior::onMouseDown(%this)
{
}

/////////////////////////////////////
// **ChurchBhv**
//   -People go here on "sunday"
//
//By Bryant Cannon 
//20 February 2009
//////////////////////////////////////


$WeekCycle = 60000;

if (!isObject(ChurchBhv))
{
   %template = new BehaviorTemplate(ChurchBhv);
   
   %template.friendlyName = "Church";
   %template.behaviorType = "EndGame";
   %template.description  = "Characters will go here at the end of the week";
   
   %template.addBehaviorField(faithQuota, "Amount of faith needed by characters in this level", int, 50);
   %template.addBehaviorField(loveQuota, "Amount of love needed by characters in this level", int, 50);
   %template.addBehaviorField(peopleQuota, "Number of people needed to complete level", int, 0);
}

function ChurchBhv::onBehaviorAdd(%this)
{
   $Church = %this.owner;
}

function ChurchBhv::onAddToScene(%this)
{
   $Church = %this.owner;
   %this.owner.churchBhv = %this;
   %this.owner.setLayer(15);
   %this.owner.enableUpdateCallback();
   
   $Church.filled = 0;
   
   $Church.churchEvent = %this.schedule($WeekCycle,checkSaved);
   
   //Add the Waypoint behavior
   if(!isObject(%this.owner.behavior(WaypointBhv)))
   {
      %bhv = WaypointBhv.createInstance();
      %this.owner.addBehavior(%bhv);
      %bhv.minX = -6;
      %bhv.maxX = 6;
      %bhv.minY = -6;
      %bhv.maxY = 6;
   }
}

function ChurchBhv::onUpdate(%this)
{
   
}

function ChurchBhv::checkSaved(%this)
{
   for(%i=0;%i<Characters.getCount();%i++)
   {
      %bhv = Characters.getObject(%i).charBhv;
      if(%bhv.faith>=%this.faithQuota && %bhv.love>=%this.loveQuota)
      {
         %this.sendToChurch(%bhv);
         echo(%bhv.charName);
      }
   }
   $bell = alxPlay(churchBellSound);
   %this.schedule($WeekCycle+15000,checkSaved);
}

function ChurchBhv::sendToChurch(%this,%charBhv)
{
   if(%charBhv.owner.free) {
      %charBhv.schedule(15000,endAction);
      %charBhv.setErrand(%this.owner);
   } else {
      //If the character is busy, try again next frame
      %this.schedule(33,sendToChurch,%charBhv);
   }
}


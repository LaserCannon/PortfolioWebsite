///////////////////////////////////////
// **WaypointBhv**
//   -Waypoint for character movement
//
//By Bryant Cannon
//18 March 2009
//////////////////////////////////////


$WAYPOINT_DIST = 13.0;

if (!isObject(WaypointBhv))
{
   %template = new BehaviorTemplate(WaypointBhv);
   
   %template.friendlyName = "Waypoint";
   %template.behaviorType = "Navigation";
   %template.description  = "Walkable point in map";
   
   %template.addBehaviorField(minX, "Minimum X offset", float, -1);
   %template.addBehaviorField(maxX, "Maximum X offset", float, 1);
   %template.addBehaviorField(minY, "Minimum Y offset", float, -1);
   %template.addBehaviorField(maxY, "Maximum Y offset", float, 1);
   
   //Make sure trigger references are set
   if(!isObject($waypoints)) {
      $waypoints = new SimSet(Waypoints);
   }
}


function WaypointBhv::onBehaviorAdd(%this)
{
   //Make a new set for all connecting nodes
   %this.owner.connects = new SimSet();
   %this.owner.wayBhv = %this;
   //Set layer and transparency only for non-triggers
   if(!Triggers.isMember(%this.owner) && %this.owner!=$Church) {
      %this.owner.setLayer(0);
      %this.owner.setBlendAlpha(0.7);
   }
   if(!Waypoints.isMember(%this.owner)) {
      Waypoints.add(%this.owner);
   }
}

function WaypointBhv::onAddToScene(%this)
{
   //Set visible if not a trigger
   if(!Triggers.isMember(%this.owner) && %this.owner!=$Church) {
      %this.owner.setVisible(false);
   }
   if(!Waypoints.isMember(%this.owner)) {
      Waypoints.add(%this.owner);
   }
   %this.owner.wayBhv = %this;
}

function WaypointBhv::onLevelLoaded(%this)
{
   //Browse through all waypoints
   for(%i=0;%i<Waypoints.getCount();%i++)
   {
      //Test to see if distance is close enough to be "connected"
      %wayp = Waypoints.getObject(%i);
      if(%wayp.getID()!=%this.owner) {
         %x = %wayp.getPositionX() - %this.owner.getPositionX();
         %y = %wayp.getPositionY() - %this.owner.getPositionY();
         if (mSqrt(mPow(%x,2)+mPow(%y,2))<=$WAYPOINT_DIST)
         {
            %this.owner.connects.add(%wayp);
         }
      }
   }
}

function WaypointBhv::onLevelEnded(%this)
{
   Waypoints.remove(%this.owner);
}

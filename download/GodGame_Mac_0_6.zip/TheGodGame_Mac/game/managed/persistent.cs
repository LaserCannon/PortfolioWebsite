$persistentObjectSet = new SimSet();

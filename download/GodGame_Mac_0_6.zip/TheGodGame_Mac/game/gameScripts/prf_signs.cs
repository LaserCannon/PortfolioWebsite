/////////////////////////////////////
// **prf_signs.cs**
//   -Sign profiles
//
//By Bryant Cannon
//12 February 2009
//////////////////////////////////////

//DESIGN NOTE:
//Each sign is "responsible" for cancelling the walk
// cycle, making the character "busy", and reinstating the
// walk cycle with endAction

$signs = new SimSet(SignSet);

//"Jesus Toast"
if(!isObject(ToastSign))
{
   %sign = new SimObject(ToastSign);
   
   %sign.actName = "Toast";
   %sign.imagePointer = Sign_Jesus_ToastImageMap;
   
   //SignSet.add(%sign);
}

function ToastSign::sign(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudAngryAniImageMap);
   %tst = newStaticSprite("tst",Sign_Jesus_ToastImageMap,%x+3,%y+1.5,0.0,true,false,5,5);
   %tst.setBlendColor(0.2,0.2,0.1);
   
   //Fade in, fade out, end action
   fadeAlpha(%tst,200,1.0);
   schedule(1000,0,fadeColor,%tst,1000,1.0,1.0,1.0,1.0);
   schedule(3500,0,fadeAlpha,%tst,800,0.0);
   %charBhv.schedule(4200,endAction);
   
   %tst.schedule(4500,delete);
}

//Burning Bush
if(!isObject(RainbowSign))
{
   %sign = new SimObject(RainbowSign);
   
   %sign.actName = "Rainbow";
   %sign.imagePointer = Sign_RainbowImageMap;
   
   SignSet.add(%sign);
}

function RainbowSign::sign(%this,%charBhv)
{
   //Set up animations
   %charBhv.beginAction();
   //%charBhv.owner.setImageMap(CloudAngryAniImageMap);
   %rb = newStaticSprite("rb",Sign_RainbowImageMap,%charBhv.owner.getPositionX()+2,%charBhv.owner.getPositionY(),0.0,true,false,30,30);
   
   //Fade in, Fade out, end action
   fadeAlpha(%rb,800,0.6);
   schedule(4000,0,fadeAlpha,%rb,800,0.0);
   %charBhv.schedule(4100,endAction);
   
   alxPlay(DreamSound);
   
   %rb.schedule(5500,delete);
}



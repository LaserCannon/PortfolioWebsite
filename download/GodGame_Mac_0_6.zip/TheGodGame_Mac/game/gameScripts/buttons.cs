///////////////////////////////////////
// **buttons.cs**
//   -Initializes buttons in the GUI
//
//By Bryant Cannon
//9 February 2009
//////////////////////////////////////

////////////////////////////////////
//**Initialize interface buttons**
////////////////////////////////////

$BTN_DIST = 8;

/////////////////////////////////
//Initialize action buttons first

if (!isObject(ActionButtonTemplate))
{
   $actionButtonTemplate = new t2dStaticSprite(ActionButtonTemplate);
   ActionButtonTemplate.setUseMouseEvents(false);
   ActionButtonTemplate.enableUpdateCallback();
   ActionButtonTemplate.setImageMap(power_button_spriteImageMap);
   ActionButtonTemplate.setVisible(false);
   ActionButtonTemplate.setLayer(1);
}

//Make an action button behavior template
if (!isObject(ActionButtonBehave))
{
   %template = new BehaviorTemplate(ActionButtonBehave);
}

function ActionButtonBehave::onMouseDown(%this)
{
   //Make sure the character is set
   if(!isObject($charSelect)) {
      error("Character " @ $charSelect @ " does not exist.");
      return;
   }
   
   //If the character is busy, make error effects and quit function
   if($charSelect.free==false)
   {
      %this.owner.setBlendColor(1,0.5,0.5);
      %this.er = newText("error","Character is Busy","Arial",2,1,0.1,0.3,1);
      %this.er.setPositionX(%this.owner.getPositionX());
      %this.er.setPositionY(%this.owner.getPositionY()+2.7);
      return;
   }
   
   if (BlessingSet.isMember(%this.owner.ref)) {
      $charSelect.charBhv.onBlessed(%this.owner.ref);
      %this.owner.ref.bless($charSelect.charBhv);
      echo("Blessed!");
   }
   else if (SignSet.isMember(%this.owner.ref)) {
      $charSelect.charBhv.onSign(%this.owner.ref);
      %this.owner.ref.sign($charSelect.charBhv);
      echo("Sign!");
   }
   else if (SmiteSet.isMember(%this.owner.ref)) {
      $charSelect.charBhv.onSmite(%this.owner.ref);
      %this.owner.ref.smite($charSelect.charBhv);
      echo("Smited!");
   }
   else {
      error("Reference from button to action is broken.");
   }
   
   //Erase Current Button record
   $CUR_BTN_OUT = "NONE";
   
   //Hide options after selection
   if(isObject($charSelect)) {
      MasterObject.hideOptions();
      $charSelect = "NULL";
   }
   MasterObject.hideLight();
}

function ActionButtonBehave::onMouseUp(%this)
{
   //Return button to regular color blending
   fadeColor(%this.owner,300,1,1,1,-1);
   if(isObject(%this.er)) {
      %this.er.safeDelete();
   }
}

function ActionButtonBehave::onMouseEnter(%this)
{
   //Set explanation text
   HelpCtrl.setText(%this.owner.ref.actName);
   
   //Make other buttons unusable
   BlessBtn.setUseMouseEvents(false);
   SignBtn.setUseMouseEvents(false);
   SmiteBtn.setUseMouseEvents(false);
}

function ActionButtonBehave::onMouseLeave(%this)
{
   //Erase explanation text
   HelpCtrl.setText(" ");
   
   //Return button to regular color blending
   %this.owner.setBlendColor(1,1,1,1);
   if(isObject(%this.er)) {
      %this.er.safeDelete();
   }
   
   //Return use of buttons
   BlessBtn.setUseMouseEvents(true);
   SignBtn.setUseMouseEvents(true);
   SmiteBtn.setUseMouseEvents(true);
}


//////////////////////////////////
//Now initialize Category buttons

/////Bless Button/////
if(!isObject(BlessBtn))
{
   $btn[0] = new t2dStaticSprite(BlessBtn);
   BlessBtn.setUseMouseEvents(false);
   BlessBtn.enableUpdateCallback();
   BlessBtn.setImageMap(BlessButtonRockImageMap);
   BlessBtn.setVisible(false);
   BlessBtn.buttons = new SimSet();
}

//Callback Functions
function BlessBtn::onMouseEnter(%this)
{
   //Fade other categories and delete the subcommand buttons
   fadeAllBut("Bless");
   
   //If character prayed for forgiveness, add the option
   if($charSelect.prayedForgiveness==true && !BlessingSet.isMember(Forgive))
   {
      addBlessing($forgive);
   }
   //Conversly, if character didn't pray for forgiveness, remove the option
   if($charSelect.prayedForgiveness==false && BlessingSet.isMember(Forgive))
   {
      removeBlessing($forgive);
   }

   //Expand the Blessing options
   for(%i=0;%i<BlessingSet.getCount();%i++)
   {
      //Make sure button isnt already there...
      if (!isObject(%this.buttons.getObject(%i)))
      {
         //Make new button
         %this.buttons.add(ActionButtonTemplate.clone(true));
         %newbehave = ActionButtonBehave.createInstance();
         %this.buttons.getObject(%i).addBehavior(%newbehave);
         %this.buttons.getObject(%i).setUseMouseEvents(true);
         //Set reference to Blessing
         %this.buttons.getObject(%i).ref = BlessingSet.getObject(%i);
         
         //Mount picture in the center of the button
         %img = new t2dStaticSprite();
         %this.buttons.getObject(%i).img = %img;
         %img.addToScene(sceneWindow2D.getSceneGraph());
         %img.setUseMouseEvents(false);
         %img.enableUpdateCallback();
         %img.setSize("3 3");
         %img.setImageMap(BlessingSet.getObject(%i).imagePointer);
         %img.mount(%this.buttons.getObject(%i),0,0,0,true,true,true,true);
      }
      
      
      //Get the position to put the button
      %num = BlessingSet.getCount();
      if(%num<=3) {
         //Seperate buttons only a little if few buttons
         %ang = (180/(%num+1))*(%i+1) + 180;
      } else {
         //Polynomial to make the end buttons place correctly
         %ang = (180/(%num)+180/(%num*%num)+180/(%num*%num*%num))*(%i) + 180;
      }
      %ang = %ang/180*3.141592;
         
      if($CUR_BTN_OUT !$= "Bless")
      {
         //And mount position/size relative to bless button
         %newx = -mCos(%ang)*$BTN_DIST;
         %newy = -mSin(%ang)*$BTN_DIST;
         %this.buttons.getObject(%i).dismount();
         %this.buttons.getObject(%i).schedule(200,mount,%this,getLocalX(%this,%newx),getLocalY(%this,%newy),0,false,true,false,false);
         %this.buttons.getObject(%i).setSize("5 5");
      
         //Set Visible!
         %this.buttons.getObject(%i).setVisible(true);
         fadeAlpha(%this.buttons.getObject(%i),200,1.0);
         fadeAlpha(%this.buttons.getObject(%i).img,200,1.0);
         //Start at the button, fan out slowly
         %this.buttons.getObject(%i).setPosition(%this.getPosition());
         %this.buttons.getObject(%i).img.setPosition(%this.getPosition());
         moveObject(%this.buttons.getObject(%i),%newx,%newy,200,false);
         moveObject(%this.buttons.getObject(%i).img,%newx,%newy,200,false);
         //Make usable
         %this.buttons.getObject(%i).setUseMouseEvents(true);
      }
   }
   //Make a sound!
   if($CUR_BTN_OUT !$= "Bless") {
      alxPlay(MenuLoSound);
   }
   
   $CUR_BTN_OUT = "Bless";
}

/////Sign Button/////
if(!isObject(SignBtn))
{
   $btn[1] = new t2dStaticSprite(SignBtn);
   SignBtn.setUseMouseEvents(false);
   SignBtn.enableUpdateCallback();
   SignBtn.setImageMap(SignButtonRockImageMap);
   SignBtn.setVisible(false);
   SignBtn.buttons = new SimSet();
}

//Callback Functions
function SignBtn::onMouseEnter(%this)
{
   //Fade other categories and delete the subcommand buttons
   fadeAllBut("Sign");
   
   //Expand the Sign options
   for(%i=0;%i<SignSet.getCount();%i++)
   {
      //Make sure buttons aren't already there...
      if (!isObject(%this.buttons.getObject(%i)))
      {
         //Make new button
         %this.buttons.add(ActionButtonTemplate.clone(true));
         %newbehave = ActionButtonBehave.createInstance();
         %this.buttons.getObject(%i).addBehavior(%newbehave);
         %this.buttons.getObject(%i).setUseMouseEvents(true); 
         //Set reference to Blessing
         %this.buttons.getObject(%i).ref = SignSet.getObject(%i);
         
         //Mount picture in the center of the button
         %img = new t2dStaticSprite();
         %this.buttons.getObject(%i).img = %img;
         %img.addToScene(sceneWindow2D.getSceneGraph());
         %img.setUseMouseEvents(false);
         %img.enableUpdateCallback();
         %img.setSize("3 3");
         %img.setImageMap(SignSet.getObject(%i).imagePointer);
         %img.mount(%this.buttons.getObject(%i),0,0,0,true,true,true,true);
      }
            
      //Get the position to put the button
      %num = SignSet.getCount();
      if(%num<=3) {
         //Seperate buttons only a little if few buttons
         %ang = (180/(%num+1))*(%i+1) + 90;
      } else {
         //Polynomial to make the end buttons place correctly
         %ang = (180/(%num)+180/(%num*%num)+180/(%num*%num*%num))*(%i) + 90;
      }
      %ang = %ang/180*3.141592;
      
      if($CUR_BTN_OUT !$= "Sign")
      {
         //And mount position/size relative to bless button
         %newx = -mCos(%ang)*$BTN_DIST;
         %newy = -mSin(%ang)*$BTN_DIST;
         %this.buttons.getObject(%i).dismount();
         %this.buttons.getObject(%i).schedule(200,mount,%this,getLocalX(%this,%newx),getLocalY(%this,%newy),0,false,true,false,false);
         %this.buttons.getObject(%i).setSize("5 5");
      
         //Set Visible!
         %this.buttons.getObject(%i).setVisible(true);
         fadeAlpha(%this.buttons.getObject(%i),200,1.0);
         fadeAlpha(%this.buttons.getObject(%i).img,200,1.0);
         //Start at the button, fan out slowly
         %this.buttons.getObject(%i).setPosition(%this.getPosition());
         %this.buttons.getObject(%i).img.setPosition(%this.getPosition());
         moveObject(%this.buttons.getObject(%i),%newx,%newy,200,false);
         moveObject(%this.buttons.getObject(%i).img,%newx,%newy,200,false);
         //Make usable
         %this.buttons.getObject(%i).setUseMouseEvents(true);
      }
   }
   //Make a sound!
   if($CUR_BTN_OUT !$= "Sign") {
      alxPlay(MenuLoSound);
   }
   
   $CUR_BTN_OUT = "Sign";
}

/////Smite Button/////
if(!isObject(SmiteBtn))
{
   $btn[2] = new t2dStaticSprite(SmiteBtn);
   SmiteBtn.setUseMouseEvents(false);
   SmiteBtn.enableUpdateCallback();
   SmiteBtn.setImageMap(SmiteButtonRockImageMap);
   SmiteBtn.setVisible(false);
   SmiteBtn.buttons = new SimSet();
}

//Callback Functions
function SmiteBtn::onMouseEnter(%this)
{
   fadeAllBut("Smite");

   //Expand the Sign options
   for(%i=0;%i<SmiteSet.getCount();%i++)
   {
      //Make sure buttons aren't already there...
      if (!isObject(%this.buttons.getObject(%i)))
      {
         //Make new button
         %this.buttons.add(ActionButtonTemplate.clone(true));
         %newbehave = ActionButtonBehave.createInstance();
         %this.buttons.getObject(%i).addBehavior(%newbehave);
         %this.buttons.getObject(%i).setUseMouseEvents(true); 
         //Set reference to Blessing
         %this.buttons.getObject(%i).ref = SmiteSet.getObject(%i);
         
         //Mount picture in the center of the button
         %img = new t2dStaticSprite();
         %this.buttons.getObject(%i).img = %img;
         %img.addToScene(sceneWindow2D.getSceneGraph());
         %img.setUseMouseEvents(false);
         %img.enableUpdateCallback();
         %img.setSize("3 3");
         %img.setImageMap(SmiteSet.getObject(%i).imagePointer);
         %img.mount(%this.buttons.getObject(%i),0,0,0,true,true,true,true);
      }
            
      //Get the position to put the button
      %num = SmiteSet.getCount();
      if(%num<=3) {
         //Seperate buttons only a little if few buttons
         %ang = (180/(%num+1))*(%i+1) - 90;
      } else {
         //Polynomial to make the end buttons place correctly
         %ang = (180/(%num)+180/(%num*%num)+180/(%num*%num*%num))*(%i) - 90;
      }
      %ang = %ang/180*3.141592;
      
      if($CUR_BTN_OUT !$= "Smite")
      {
         //And mount position/size relative to bless button
         %newx = -mCos(%ang)*$BTN_DIST;
         %newy = -mSin(%ang)*$BTN_DIST;
         %this.buttons.getObject(%i).dismount();
         %this.buttons.getObject(%i).schedule(200,mount,SmiteBtn,getLocalX(%this,%newx),getLocalY(%this,%newy),0,false,true,false,false);
         %this.buttons.getObject(%i).setSize("5 5");
      
         //Set Visible!
         %this.buttons.getObject(%i).setVisible(true);
         fadeAlpha(%this.buttons.getObject(%i),200,1.0);
         fadeAlpha(%this.buttons.getObject(%i).img,200,1.0);
         //Start at the button, fan out slowly
         %this.buttons.getObject(%i).setPosition(%this.getPosition());
         %this.buttons.getObject(%i).img.setPosition(%this.getPosition());
         moveObject(%this.buttons.getObject(%i),%newx,%newy,200,false);
         moveObject(%this.buttons.getObject(%i).img,%newx,%newy,200,false);
         //Make usable
         %this.buttons.getObject(%i).setUseMouseEvents(true);
      }
   }
   //Make a sound!
   if($CUR_BTN_OUT !$= "Smite") {
      alxPlay(MenuLoSound);
   }
   
   $CUR_BTN_OUT = "Smite";
}


//////////UTILITY FUNCTIONS for Buttons/////////////
function fadeAllBut(%notFade)
{
   //Fade all but the used button and clear unneeded action buttons
   if (%notFade $= "Bless")
   {
      fadeColor(BlessBtn,200,1.0,1.0,1.0,1.0);
      fadeColor(SignBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(SignBtn);
      fadeColor(SmiteBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(SmiteBtn);
   }
   else if (%notFade $= "Sign")
   {
      fadeColor(BlessBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(BlessBtn);
      fadeColor(SignBtn,200,1.0,1.0,1.0,1.0);
      fadeColor(SmiteBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(SmiteBtn);
   }
   else if (%notFade $= "Smite")
   {
      fadeColor(BlessBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(BlessBtn);
      fadeColor(SignBtn,200,0.5,0.5,0.5,0.5);
      clearButtons(SignBtn);
      fadeColor(SmiteBtn,200,1.0,1.0,1.0,1.0);
   }
   else
   {
      fadeColor(BlessBtn,200,1.0,1.0,1.0,1.0);
      clearButtons(BlessBtn);
      fadeColor(SignBtn,200,1.0,1.0,1.0,1.0);
      clearButtons(SignBtn);
      fadeColor(SmiteBtn,200,1.0,1.0,1.0,1.0);
      clearButtons(SmiteBtn);
   }
}

function clearButtons(%btn)
{
   %size = %btn.buttons.getCount();
   //Clear all action buttons sprouting from '%btn'
   for(%i=0;%i<%size;%i++)
   {
      if (isObject(%btn.buttons.getObject(%i))) {
         //Make sure button can't be used
         %btn.buttons.getObject(%i).setUseMouseEvents(false);
         //...Nor seen
         fadeAlpha(%btn.buttons.getObject(%i),200,0.0);
         fadeAlpha(%btn.buttons.getObject(%i).img,200,0.0);
         moveObject(%btn.buttons.getObject(%i),%btn.getPositionX(),%btn.getPositionY(),200,true);
         moveObject(%btn.buttons.getObject(%i).img,%btn.getPositionX(),%btn.getPositionY(),200,true);
         //And dismount it
         %btn.buttons.getObject(%i).dismount();
      }
      else {
         error("Count error in clearButtons()");
      }
   }
}

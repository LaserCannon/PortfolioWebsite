/////////////////////////////////////
// **weekTimer.cs**
//   -Provides timer for 
//
//By Bryant Cannon
//15 February 2009
//////////////////////////////////////

/*$DAY_TIME = 50*1000;

if (!isObject(WeekTimer))
{
   $weekTimer = new t2dSceneObject(WeekTimer);
   
   $weekTimer.day = 1;
   $weekTimer.enableUpdateCallback();
   
}

function WeekTimer::onUpdate(%this)
{
   if($TutOn) { %this.resetTimer(); return; }
   %text = %this.getDay() SPC %this.getTimeOfDay(false);
   DayCtrl.setText(%text);
}

function WeekTimer::progressTimer(%this)
{
   if (%this.day < 7)
   {
      //Incriment day and start timer again
      %this.day++;
      if (isEventPending(%this.timer)){
         cancel(%this.timer);
      }
      %this.timer = %this.schedule($DAY_TIME,progressTimer);
   }
}

function WeekTimer::resetTimer(%this)
{
   %this.day = 1;
   if (isEventPending(%this.timer)){
      cancel(%this.timer);
   }
   %this.timer = %this.schedule($DAY_TIME,progressTimer);
}

function WeekTimer::getDay(%this)
{
   switch(%this.day)
   {
   case 1:
      return "Monday";
   case 2:
      return "Tuesday";
   case 3:
      return "Wednesday";
   case 4:
      return "Thursday";
   case 5:
      return "Friday";
   case 6:
      return "Saturday";
   case 7:
      return "Sunday";
   }
   return "ERROR";
}

function WeekTimer::getHour()
{
   %t = $DAY_TIME - getEventTimeLeft($timer);
   %hour = mFloor((%t/$DAY_TIME)*24);
   return %hour;
}

function WeekTimer::getTimeOfDay(%this,%military)
{
   %t = $DAY_TIME - getEventTimeLeft($timer);
   %hour = mFloor((%t/$DAY_TIME)*24);
   %min = mFloor((((%t/$DAY_TIME)*24)-%hour)*60);
   if (%min<10)   { %min = "0" @ %min; }
   if (%military) {
      %time = %hour @ ":" @ %min;
   }
   else {
      //Set AM/PM
      if (%hour >= 12)  { %ext = "PM"; }
      else              { %ext = "AM"; }
      //Adjust hour
      if (%hour > 12)   { %hour-=12; }
      if (%hour == 0)   { %hour = 12; }
      
      //Set string
      %time = %hour @ ":" @ %min SPC %ext;
   }
   
   return %time;
}*/

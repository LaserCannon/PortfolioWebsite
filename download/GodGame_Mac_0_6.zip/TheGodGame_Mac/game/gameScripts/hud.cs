///////////////////////////////////////
// **hud.cs**
//   -Initializes the HUD display objects
//
//By Bryant Cannon
//9 February 2009
//////////////////////////////////////

/////Faith Meter/////
if(!isObject(FaithTemplate))
{
   %faithTemplate = new t2dStaticSprite(FaithTemplate);
   FaithTemplate.setUseMouseEvents(true);
   FaithTemplate.enableUpdateCallback();
   FaithTemplate.setVisible(false);
   FaithTemplate.setImageMap(Faith_Icon_UsableImageMap);
   FaithTemplate.setSize(3,3);
   FaithTemplate.setLayer(2);
   FaithTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(FaithBehave))
{
   %template = new BehaviorTemplate(FaithBehave);
   %template.friendlyName = "Faith Meter";
}
function FaithBehave::onLevelLoaded(%this)
{
   %this.backSprite = newStaticSprite("backF",Faith_Icon_BackgroundImageMap,0,0,0.3,true,false,3,3);
   %this.backSprite.setLayer(3);
   %this.backSprite.mount(%this.obj);
}
function FaithBehave::onMouseEnter(%this)
{
   //scaleObject(%this.obj,5,5,100,true);
}
function FaithBehave::onMouseLeave(%this)
{
   //scaleObject(%this.obj,3,3,100,true);
}
function FaithBehave::onUpdate(%this)
{
   //If the character exists, adjust the transparency
   if (%this.obj.char !$= "NULL")
   {
      //OLD CODE: Adjusts both SIZE and OPACITY based on faith
      //%this.obj.setBlendAlpha(%this.obj.char.charBhv.faith/200 + 0.5);
      //%this.obj.setSize(%this.obj.char.charBhv.faith/50 + 1,%this.obj.char.charBhv.faith/50 + 1);
      //New code: Adjusts SIZE on faith and OPACITY based on apathy
      %this.obj.setSize(%this.obj.char.charBhv.faith/40 + 0.5,%this.obj.char.charBhv.faith/40 + 0.5);
      %this.obj.setBlendAlpha(1-(%this.obj.char.charBhv.apathy/111 + 0.1));
   }
}


/////Love Meter/////
if(!isObject(LoveTemplate))
{
   %loveTemplate = new t2dStaticSprite(LoveTemplate);
   LoveTemplate.setUseMouseEvents(true);
   LoveTemplate.enableUpdateCallback();
   LoveTemplate.setVisible(false);
   LoveTemplate.setImageMap(HeartImageMap);
   LoveTemplate.setSize(3,3);
   LoveTemplate.setLayer(2);
   LoveTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(LoveBehave))
{
   %template = new BehaviorTemplate(LoveBehave);
   %template.friendlyName = "Love Meter";
}
function LoveBehave::onLevelLoaded(%this)
{
   %this.backSprite = newStaticSprite("backH",Heart_Icon_BackgroundImageMap,0,0,0.3,true,false,3,3);
   %this.backSprite.setLayer(3);
   %this.backSprite.mount(%this.obj);
}
function LoveBehave::onMouseEnter(%this)
{
   //scaleObject(%this.obj,5,5,100,true);
}
function LoveBehave::onMouseLeave(%this)
{
   //scaleObject(%this.obj,3,3,100,true);
}
function LoveBehave::onUpdate(%this)
{
   //If the character exists, adjust the transparency
   if (%this.owner.char !$= "NULL")
   {
      //OLD CODE: Adjusts both SIZE and OPACITY based on love
      //%this.obj.setBlendAlpha(%this.obj.char.charBhv.love/200 + 0.5);
      //%this.obj.setSize(%this.obj.char.charBhv.love/50 + 1,%this.obj.char.charBhv.love/50 + 1);
      //New code: Adjusts SIZE on love and OPACITY based on apathy
      %this.obj.setSize(%this.obj.char.charBhv.love/40 + 0.5,%this.obj.char.charBhv.love/40 + 0.5);
      %this.obj.setBlendAlpha(1-(%this.obj.char.charBhv.apathy/111 + 0.1));
   }
}


/////"Shamed" Indicator/////
if(!isObject(ShameTemplate))
{
   $shameTemplate = new t2dAnimatedSprite(ShameTemplate);
   ShameTemplate.setUseMouseEvents(false);
   ShameTemplate.enableUpdateCallback();
   ShameTemplate.setVisible(false);
   ShameTemplate.setAnimation(RainCloudAnimAnimation);
   ShameTemplate.setSize(5,4);
   ShameTemplate.setLayer(4);
   ShameTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(ShameBehave))
{
   %template = new BehaviorTemplate(ShameBehave);
}
function ShameBehave::onMouseEnter(%this)
{
}
function ShameBehave::onMouseLeave(%this)
{
}
function ShameBehave::onUpdate(%this)
{
   //If the character exists, adjust the visibility
   if (%this.obj.char !$= "NULL")
   {
      %this.obj.setVisible(%this.obj.char.charBhv.shamed);
   }
}

/////Anger Meter/////
if(!isObject(AngerTemplate))
{
   %angerTemplate = new t2dStaticSprite(AngerTemplate);
   AngerTemplate.setUseMouseEvents(true);
   AngerTemplate.enableUpdateCallback();
   AngerTemplate.setVisible(false);
   AngerTemplate.setImageMap(anger2ImageMap);
   AngerTemplate.setSize(3,3);
   AngerTemplate.setLayer(4);
   AngerTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(AngerBehave))
{
   %template = new BehaviorTemplate(AngerBehave);
   %template.friendlyName = "Anger Meter";
}
function AngerBehave::onMouseEnter(%this)
{
}
function AngerBehave::onMouseLeave(%this)
{
}
function AngerBehave::onUpdate(%this)
{
   //If the character exists, adjust the transparency
   if (%this.obj.char !$= "NULL")
   {
      %this.obj.setBlendAlpha((%this.obj.char.charBhv.anger-40)/60);
   }
}


/////Prayer bubbles/////
if(!isObject(PrayerBubbleTemplate))
{
   $bubbleTemplate = new t2dStaticSprite(PrayerBubbleTemplate);
   PrayerBubbleTemplate.setUseMouseEvents(false);
   PrayerBubbleTemplate.enableUpdateCallback();
   PrayerBubbleTemplate.setVisible(true);
   PrayerBubbleTemplate.setBlendAlpha(0);
   PrayerBubbleTemplate.setImageMap(Prayer_Bubble_SpriteImageMap);
   PrayerBubbleTemplate.setSize(6,6);
   PrayerBubbleTemplate.setLayer(2);
   PrayerBubbleTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(BubbleBehave))
{
   %template = new BehaviorTemplate(BubbleBehave);
}
function BubbleBehave::onMouseEnter(%this)
{
}
function BubbleBehave::onMouseLeave(%this)
{
}
function BubbleBehave::onUpdate(%this)
{
   //If the character exists, adjust the visibility
   if (%this.obj.char !$= "NULL")
   {
   }
}

/*if(!isObject(InteractiveBubbleTemplate))
{
   $interactiveBubbleTemplate = new t2dStaticSprite(InteractiveBubbleTemplate);
   InteractiveBubbleTemplate.setUseMouseEvents(true);
   InteractiveBubbleTemplate.enableUpdateCallback();
   InteractiveBubbleTemplate.setVisible(false);
   InteractiveBubbleTemplate.setImageMap(BubbleImageMap);
   InteractiveBubbleTemplate.setSize(4,4);
   InteractiveBubbleTemplate.setLayer(2);
   InteractiveBubbleTemplate.char = "NULL";
}
//Behavior Callback Functions
if (!isObject(InteractiveBubbleBehave))
{
   %template = new BehaviorTemplate(InteractiveBubbleBehave);
}
function InteractiveBubbleBehave::onMouseEnter(%this)
{
   if(!%this.obj.char.charBhv.praying) {
      MasterObject.displayPrayerBubbles(%this.obj.char.charBhv);
   }
}
function InteractiveBubbleBehave::onMouseLeave(%this)
{
   if(!%this.obj.char.charBhv.praying) {
      MasterObject.shrinkPrayerBubbles(%this.obj.char.charBhv);
   }
}
function InteractiveBubbleBehave::onUpdate(%this)
{
   //If the desires exist, adjust the visibility
   if (%this.obj.char.charBhv.getNumPrayedFor()>0 && !%this.obj.char.charBhv.praying) {
      %this.obj.setVisible(true);
      %this.obj.setUseMouseEvents(true);
   }
   else {
      %this.obj.setVisible(false);
      %this.obj.setUseMouseEvents(false);
   }
}*/


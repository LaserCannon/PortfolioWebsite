if(!isObject(tutorialBhvTemp))
{
   %temp = new BehaviorTemplate(tutorialBhvTemp);
}

function tutorialBhvTemp::onAddToScene(%this)
{
   $TutOn=true;
   %this.owner.setImageMap(Tutorial_Screen_1ImageMap);
   %this.set = 1;
   %this.owner.setSize("128 80");
   %this.owner.setPosition("0 0");
   $charList.getObject(0).setFree(false);
   %this.owner.setUseMouseEvents(true);
   %this.owner.setVisible(true);
}

function tutorialBhvTemp::onMouseDown(%this)
{
   if(%this.set == 7)
   {
      $charList.getObject(0).schedule(2000,setGoal);
      
      YearTimer.resetTimer(25);
      $charList.getObject(0).setFree(true);
      %this.owner.setVisible(false);
      $TutOn=false;
   }
   %this.set+=1;
   fadeColor(%this.owner,400,0,0,0,1);
   %this.owner.schedule(400,setImageMap,"Tutorial_Screen_" @ %this.set @ "ImageMap");
   schedule(500,0,fadeColor,%this.owner,400,1,1,1,1);
   return %this.set;
}

/////////////////////////////////////
// **actionManager.cs**
//   -Set of functions that add and remove blessings/signs/smites
//
//By Bryant Cannon
//15 February 2009
//////////////////////////////////////


//ADD Functions
function addBlessing(%bless)
{
   if(!BlessingSet.isMember(%bless))
   {
      BlessingSet.add(%bless);
   }
}

function addSign(%sign)
{
   if(!SignSet.isMember(%sign))
   {
      SignSet.add(%sign);
   }
}

function addSmite(%smite)
{
   if(!SmiteSet.isMember(%smite))
   {
      SmiteSet.add(%smite);
   }
}

//REMOVE Functions
function removeBlessing(%bless)
{
   if(BlessingSet.isMember(%bless))
   {
      BlessingSet.remove(%bless);
      for(%i=0;%i<BlessBtn.buttons.getCount();%i++) {
         %test = BlessBtn.buttons.getObject(%i);
         if(%test.ref.getID() == %bless.getID()) {
            BlessBtn.buttons.remove(%test);
            %test.safeDelete();
         }
      }
   }
}

function removeSign(%sign)
{
   if(SignSet.isMember(%sign))
   {
      SignSet.remove(%sign);
      for(%i=0;%i<SignBtn.buttons.getCount();%i++) {
         %test = SignBtn.buttons.getObject(%i);
         if(%test.ref.getID() == %sign.getID()) {
            SignBtn.buttons.remove(%test);
            %test.safeDelete();
         }
      }
   }
}

function removeSmite(%smite)
{
   if(SmiteSet.isMember(%smite))
   {
      SmiteSet.remove(%smite);
      for(%i=0;%i<SmiteBtn.buttons.getCount();%i++) {
         %test = SmiteBtn.buttons.getObject(%i);
         if(%test.ref.getID() == %smite.getID()) {
            SmiteBtn.buttons.remove(%test);
            %test.safeDelete();
         }
      }
   }
}

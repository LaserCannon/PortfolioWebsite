/////////////////////////////////////
// **prf_sins.cs**
//   -Sin profiles
//
//By Bryant Cannon
//28 March 2009
//////////////////////////////////////

//DESIGN NOTE:
//Each sign is "responsible" for cancelling the walk
// cycle, making the character "busy", and reinstating the
// walk cycle with endAction

$sins = new SimSet(SinSet);

//"Strip Club"
if(!isObject(StripClubSin))
{
   %sin = new SimObject(StripClubSin);
   
   %sin.actName = "Strip Club";
   %sin.blessAssociate = AffectionBless;
   
   SinSet.add(%sin);
}

function StripClubSin::sin(%this,%charBhv)
{
   %charBhv.beginAction();
   %charBhv.schedule(2000,endAction);
}
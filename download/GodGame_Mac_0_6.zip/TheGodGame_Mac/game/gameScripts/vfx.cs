///////////////////////////////////////
// **vfx.cs**
//   -Fades
//   -Dynamic sprites
//
//By Bryant Cannon
//12 February 2009
//////////////////////////////////////

/////////////////
//   FADE      //
/////////////////

function fadeColor(%obj,%time,%toRed,%toGreen,%toBlue,%toAlpha)
{
   //Check for fading already happening
   if(isEventPending(%obj._fadeEvent)) { 
      cancel(%obj._fadeEvent);
      cancel(%obj._fadeTracker);
   }
   
   //Set up a time tracker if this is the first iteration
   if(!isEventPending(%obj._fadeTracker)) {
      %obj._fadeTracker = schedule(%time,0,finish);
      %obj._fadeEvent = schedule(32,0,fadeColor,%obj,getEventTimeLeft(%obj._fadeTracker),%toRed,%toGreen,%toBlue,%toAlpha);
      return;
   }
   
   //Find current values
   %r = getWord(%obj.getBlendColor(),0);
   %g = getWord(%obj.getBlendColor(),1);
   %b = getWord(%obj.getBlendColor(),2);
   %a = getWord(%obj.getBlendColor(),3);
   
   //Find which values to change
   if(%toRed<0.0||%toRed>1.0) { %toRed = %r; }
   if(%toGreen<0.0||%toGreen>1.0) { %toGreen = %g; }
   if(%toBlue<0.0||%toBlue>1.0) { %toBlue = %b; }
   if(%toAlpha<0.0||%toAlpha>1.0) { %toAlpha = %a; }
   
   //Calculate interval changes
   %nowr = %r + (%toRed-%r)/(%time/32);
   %nowg = %g + (%toGreen-%g)/(%time/32);
   %nowb = %b + (%toBlue-%b)/(%time/32);
   %nowa = %a + (%toAlpha-%a)/(%time/32);
   
   //Set new color
   %obj.setBlendColor(%nowr,%nowg,%nowb,%nowa);
   
   if(%time >= 65) {
      %obj._fadeEvent = schedule(32,0,fadeColor,%obj,getEventTimeLeft(%obj._fadeTracker),%toRed,%toGreen,%toBlue,%toAlpha);
   }
   else {
      %obj.schedule(32,setBlendColor,%toRed,%toGreen,%toBlue,%toAlpha);
   }
}

function fadeAlpha(%obj,%time,%toAlpha)
{
   fadeColor(%obj,%time,-1,-1,-1,%toAlpha);
}

//////////////////////////
//       TEXT
//////////////////////////

function newText(%name,%text,%font,%size,%red,%green,%blue,%alpha)
{
   %newt = new t2dTextObject(%name) {
      canSaveDynamicFields = "1";
      size = "1 1";
      text = %text;
      font = %font;
      wordWrap = "0";
      hideOverflow = "0";
      textAlign = "Center";
      lineHeight = %size;
      aspectRatio = "1";
      lineSpacing = "0";
      characterSpacing = "0";
      autoSize = "1";
      fontSizes = "100";
      textColor = %red SPC %green SPC %blue SPC %alpha;
         hideOverlap = "0";
         mountID = "7";
   };
   %newt.addToScene(sceneWindow2D.getSceneGraph());
   %newt.setVisible(true);
   
   return %newt;
}

function simpleFloatUpFade(%obj,%stX,%stY,%delete)
{
   //Return if error
   if(!isObject(%obj)) {
      error("ERROR: Text object not found.");
      return;
   }
   
   %obj.setVisible(true);
   %obj.setPosition(%stX SPC %stY);
   moveObject(%obj,0,-6,2000,false);
   schedule(1000,0,fadeAlpha,%obj,700,0.0);
   if(%delete) {
      %obj.schedule(3000,delete);
   }
}

function statChangeEffect(%text,%amt,%x,%y,%flag)
{
   //While counter
   %i=0;
   
   //If "singleFloat"
   if (%flag $= "singleFloat")
   {
      if(%amt>0) {
         %img = newText("txt",%text @ "+" @ %amt,"Altenglisch MF",2,0,0,1,0.8);
         simpleFloatUpFade(%img,%x,%y,true);
      }
      else {
         %img = newText("txt",%text @ %amt,"Altenglisch MF",2,1,0,0,0.8);
         simpleFloatUpFade(%img,%x,%y,true);
      }
   }
   //If "multiFloat"
   else if (%flag $= "multiFloat")
   {
      while(%amt>0) {
         %amt-=1;
         %img = newText("txt","+" @ %text,"Altenglisch MF",2,0,0,1,0.8);
         schedule(%i*200,0,simpleFloatUpFade,%img,%x,%y,true);
         %i++;
      }
      while(%amt<0) {
         %amt+=1;
         %img = newText("txt","-" @ %text,"Altenglisch MF",2,1,0,0,0.8);
         schedule(%i*200,0,simpleFloatUpFade,%img,%x,%y,true);
         %i++;
      }
   }
   else /*if (%flag $= "sizeVary")*/ {
      if(%amt>0) {
         %img = newText("txt",%text,"Altenglisch MT",%amt/3,0,0,1,0.8);
         simpleFloatUpFade(%img,%x,%y,true);
      }
      else {
         %img = newText("txt",%text,"Altenglisch MT",%amt/3,1,0,0,0.8);
         simpleFloatUpFade(%img,%x,%y,true);
      }
   }
}



////////////////////////////////
//    MOVEMENT/SCALE/ROTATION 
/////////////////////////////////

function moveObject(%obj,%tox,%toy,%time,%abs)
{
   //Make sure object is valid
   if(!isObject(%obj)) {
      error("Error in moveObject(): " @ %obj.getName() @ " does not exist");
      return;
   }
   
   //Get current values
   %x = %obj.getPositionX();
   %y = %obj.getPositionY();
   
   //Adjust if relative
   if (!%abs) {
      %tox = %x+%tox;
      %toy = %y+%toy;
   }
   
   //Check for moving already happening
   if(isEventPending(%obj._moveEvent)) { 
      cancel(%obj._moveEvent);
      cancel(%obj._moveTracker);
   }
   
   //Set up a time tracker if this is the first iteration
   if(!isEventPending(%obj._moveTracker)) {
      %obj._moveTracker = schedule(%time,0,finish);
      %obj._moveEvent = schedule(32,0,moveObject,%obj,%tox,%toy,getEventTimeLeft(%obj._moveTracker),true);
      return;
   }
   
   //Calculate interval changes
   %x = %x + (%tox-%x)/(%time/32);
   %y = %y + (%toy-%y)/(%time/32);
   
   //Set updated position
   %obj.setPositionX(%x);
   %obj.setPositionY(%y);
   
   //Schedule update at next frame
   if(%time > 65) {
      %obj._moveEvent = schedule(32,0,moveObject,%obj,%tox,%toy,getEventTimeLeft(%obj._moveTracker),true);
   }
   else {
      %obj.schedule(32,setPosition,%tox SPC %toy);
   }
}

function scaleObject(%obj,%tox,%toy,%time,%abs)
{
   //Get current values
   %x = %obj.getSizeX();
   %y = %obj.getSizeY();
   
   //Adjust if relative
   if (!%abs) {
      %tox = %x+%tox;
      %toy = %y+%toy;
   }
   
   //Check for scaling already happening
   if(isEventPending(%obj._scaleEvent)) { 
      cancel(%obj._scaleEvent);
      cancel(%obj._scaleTracker);
   }
   
   //Set up a time tracker, start scale, and exit if this is the first iteration
   if(!isEventPending(%obj._scaleTracker)) {
      %obj._scaleTracker = schedule(%time,0,finish);
      %obj._scaleEvent = schedule(32,0,scaleObject,%obj,%tox,%toy,getEventTimeLeft(%obj._scaleTracker),true);
      return;
   }
   
   //Calculate interval changes
   %x = %x + (%tox-%x)/(%time/32);
   %y = %y + (%toy-%y)/(%time/32);
   
   //Set updated position
   %obj.setSize(%x SPC %y);
   
   //Schedule update at next frame
   if(%time > 65) {
      %obj._ScaleEvent = schedule(32,0,scaleObject,%obj,%tox,%toy,getEventTimeLeft(%obj._scaleTracker),true);
   }
   else {
      %obj.schedule(32,setSize,%tox SPC %toy);
   }
}

function finish()
{
   //Dummy function
}


//TODO: moveObject with exponential (soft) movement
/*function moveObjectExp(%obj,%tox,%toy,%time,%sharpBeg,%sharpEnd,%abs)
{
   //Get current values
   %x = %obj.getPositionX();
   %y = %obj.getPositionY();
   
   //Adjust if relative
   if (!%abs) {
      %tox = %x+%tox;
      %toy = %y+%toy;
   }
   
   //Calculate interval changes
   %x = %x + (%tox-%x)/(%time/33);
   %y = %y + (%toy-%y)/(%time/33);
   
   //Set updated position
   %obj.setPositionX(%x);
   %obj.setPositionY(%y);
   
   //Schedule update at next frame
   if(%time > 33) {
      schedule(33,0,moveObject,%obj,%tox,%toy,%time-33,true);
   }
}*/


/////////////////////
//   EASY SPAWN
/////////////////////

function newStaticSprite(%name,%imageMap,%x,%y,%alpha,%visible,%mouse,%sizex,%sizey)
{
   //Create a new dynamic sprite
   %newbtn = new t2dStaticSprite(%name);
   %newbtn.addToScene(sceneWindow2D.getSceneGraph());
   %newbtn.setVisible(false);
   %newbtn.setLayer(4);
   %newbtn.setPosition(%x SPC %y);
   %newbtn.setBlendAlpha(%alpha);
   %newbtn.setUseMouseEvents(%mouse);
   %newbtn.enableUpdateCallback();
   %newbtn.setImageMap(%imageMap);
   %newbtn.setVisible(%visible);
   if(%sizex>0) {
      %newbtn.setSizeX(%sizex);
   }
   
   if(%sizey>0) {
      %newbtn.setSizeY(%sizey);
   }
   
   return %newbtn;
}

function newAnimatedSprite(%name,%animation,%x,%y,%alpha,%visible,%mouse,%sizex,%sizey)
{
   //Create a new dynamic sprite
   %newbtn = new t2dAnimatedSprite(%name);
   %newbtn.addToScene(sceneWindow2D.getSceneGraph());
   %newbtn.setVisible(false);
   %newbtn.setLayer(4);
   %newbtn.setPosition(%x SPC %y);
   %newbtn.setBlendAlpha(%alpha);
   %newbtn.setUseMouseEvents(%mouse);
   %newbtn.enableUpdateCallback();
   %newbtn.setAnimation(%animation);
   %newbtn.setVisible(%visible);
   if(%sizex>0) {
      %newbtn.setSizeX(%sizex);
   }
   
   if(%sizey>0) {
      %newbtn.setSizeY(%sizey);
   }
   
   return %newbtn;
} 

function distance(%x1,%y1,%x2,%y2)
{
   %d = mPow(%x1-%x2,2)+mPow(%y1-%y2,2);
   return mSqrt(%d);
}

function objDistance(%obj1,%obj2)
{
   %x1=%obj1.getPositionX();
   %y1=%obj1.getPositionY();
   %x2=%obj2.getPositionX();
   %y2=%obj2.getPositionY();
   %d = mPow(%x1-%x2,2)+mPow(%y1-%y2,2);
   return mSqrt(%d);
}

function getLocalX(%obj,%xOff)
{
   %x = getWord(%obj.getLocalPoint(%obj.getPositionX()+%xOff,0),0);
   return %x;
}

function getLocalY(%obj,%yOff)
{
   %y = getWord(%obj.getLocalPoint(0,%obj.getPositionY()+%yOff),1);
   return %y;
}


/////////////////////////////////////
//   EASY UNSCHEDULE (not visual)
/////////////////////////////////////

function unschedule(%event)
{
   cancel(%event);
   return 0;
}


///////////////////////////////////////
// **SinTriggerBhv**
//   -Object will "tempt" a character
//
//By Bryant Cannon
//4 February 2009
//////////////////////////////////////

//Constants
$SIN_CAST_RATE = 20;

if (!isObject(SinTriggerBhv))
{
   %template = new BehaviorTemplate(SinTriggerBhv);
   
   %template.friendlyName = "SinTrigger";
   %template.behaviorType = "Trigger";
   %template.description  = "Object \"tempts\" a character.";
   
   %template.addBehaviorField(sinPrf, "Sin Profile", string, "");
   %template.addBehaviorField(temptation, "Strength of 'temptation' (0-10)", int, 2);
   %template.addBehaviorField(shameRand, "Chance of 'shaming' (0-10)", int, 5);
   %template.addBehaviorField(temptRadius, "Radius that character is tempted", float, 5);
   
   //Make sure trigger references are set
   if(!isObject($triggers)) {
      $triggers = new SimSet(Triggers);
   }
   if(!isObject($sinTriggers)) {
      $sinTriggers = new SimSet(SinTriggers);
   }
}

function SinTriggerBhv::onLevelEnded(%this)
{
   Triggers.remove(%this.owner);
   SinTriggers.remove(%this.owner);
}

function SinTriggerBhv::onAddToScene(%this)
{
   //Add to main list
   Triggers.add(%this.owner);
   SinTriggers.add(%this.owner);
   
   //Add the Waypoint behavior
   if(!isObject(%this.owner.behavior(WaypointBhv)))
   {
      %bhv = WaypointBhv.createInstance();
      %this.owner.addBehavior(%bhv);
      %bhv.minX = -3.5;
      %bhv.maxX = 3.5;
      %bhv.minY = -3.5;
      %bhv.maxY = 3.5;
   }
   
   %this.owner.setLayer(10);
   %this.owner.sinBhv = %this;
}

function SinTriggerBhv::onBehaviorAdd(%this)
{
   %this.owner.enableUpdateCallback();
   %this.owner.setUseMouseEvents(true);
   
   %this.owner.setLayer(10);
   
   %this.owner.sinBhv = %this;
}

function SinTriggerBhv::onUpdate(%this)
{
   if(getRandom(0,1000) < $SIN_CAST_RATE)
   {
      %this.roleTempt();
   }
}

function SinTriggerBhv::roleTempt(%this)
{
   for(%i=0;%i<$charList.getCount();%i++)
   {
      %subj = $charList.getObject(%i);
      %x = %subj.getPositionX() - %this.owner.getPositionX();
      %y = %subj.getPositionY() - %this.owner.getPositionY();
      if (mSqrt(mPow(%x,2)+mPow(%y,2)) < 5.0)
      {
         if(%subj.charBhv.isFree())
         {
            %subj.charBhv.roleSin(%this.temptation,%this.owner);
            return;
         }
      }
      else if(mSqrt(mPow(%x,2)+mPow(%y,2)) < %this.temptRadius)
      {
         if(%subj.goal.getID() != %this.owner) {
            %subj.charbhv.setNewGoal(%this.owner);
         }
      }
   }
}


/////////////////////////////////////
// **prf_character.cs**
//   -Character profiles
//
//By Bryant Cannon
//15 March 2009
//////////////////////////////////////

$characterPrfs = new SimSet(CharacterPrfs);

if(!isObject(FelixPrf))
{
   %charPrf = new SimObject(FelixPrf);
   
   ////BODY////
   //Idle Animations
   %charPrf.upAnim = felixWalkUpAnimation;
   //%charPrf.upRightAnim
   %charPrf.rightAnim = felixWalkRightAnimation;
   //%charPrf.downRightAnim
   %charPrf.downAnim = felixWalkDownAnimation;
   //%charPrf.downLeftAnim
   %charPrf.leftAnim = felixWalkLeftAnimation;
   //%charPrf.upLeftAnim
   
   %charPrf.idleUpAnim = felixIdleUpAnimation;
   //%charPrf.idleUpRightAnim
   %charPrf.idleRightAnim = felixIdleRightAnimation;
   //%charPrf.idleDownRightAnim
   %charPrf.idleDownAnim = felixIdleDownAnimation;
   //%charPrf.idleDownLeftAnim
   %charPrf.idleLeftAnim = felixIdleLeftAnimation;
   //%charPrf.idleUpLeftAnim
   
   ////ACTIONS////
   %charPrf.prayerAnim = felixPrayAnimation;
   //%charPrf.supriseAnim
   
   CharacterPrfs.add(%charPrf);
}

if(!isObject(BlueJewPrf))
{
   %charPrf = new SimObject(BlueJewPrf);
   
   ////BODY////
   //Idle Animations
   //%charPrf.upAnim
   %charPrf.upRightAnim = BlueUpRightAnimation;
   //%charPrf.rightAnim
   %charPrf.downRightAnim = BlueDownRightAnimation;
   //%charPrf.downAnim
   %charPrf.downLeftAnim = BlueDownleftAnimation;
   //%charPrf.leftAnim
   %charPrf.upLeftAnim = BlueUpleftAnimation;
   
   //%charPrf.idleUpAnim
   %charPrf.idleUpRightAnim = BlueUpRightIdleAnimation;
   //%charPrf.idleRightAnim
   %charPrf.idleDownRightAnim = BlueDownRightIdleAnimation;
   //%charPrf.idleDownAnim
   %charPrf.idleDownLeftAnim = BlueDownleftIdleAnimation;
   //%charPrf.idleLeftAnim
   %charPrf.idleUpLeftAnim = BlueUpleftIdleAnimation;
   
   ////ACTIONS////
   %charPrf.prayerAnim = BluePrayAnimation;
   //%charPrf.supriseAnim
   
   ////GHOST////
   %charPrf.ghostRightAnim = BlueDownRightIdleGhostAnimation;
   %charPrf.ghostLeftAnim = BlueDownleftIdleGhostAnimation;
   
   CharacterPrfs.add(%charPrf);
}

if(!isObject(GreenJewPrf))
{
   %charPrf = new SimObject(GreenJewPrf);
   
   ////BODY////
   //Idle Animations
   //%charPrf.upAnim
   %charPrf.upRightAnim = GreenUpRightAnimation;
   //%charPrf.rightAnim
   %charPrf.downRightAnim = GreenDownRightAnimation;
   //%charPrf.downAnim
   %charPrf.downLeftAnim = GreenDownleftAnimation;
   //%charPrf.leftAnim
   %charPrf.upLeftAnim = GreenUpleftAnimation;
   
   //%charPrf.idleUpAnim
   %charPrf.idleUpRightAnim = GreenUpRightIdleAnimation;
   //%charPrf.idleRightAnim
   %charPrf.idleDownRightAnim = GreenDownRightIdleAnimation;
   //%charPrf.idleDownAnim
   %charPrf.idleDownLeftAnim = GreenDownleftIdleAnimation;
   //%charPrf.idleLeftAnim
   %charPrf.idleUpLeftAnim = GreenUpleftIdleAnimation;
   
   ////ACTIONS////
   %charPrf.prayerAnim = GreenPrayAnimation;
   //%charPrf.supriseAnim
   
   ////GHOST////
   %charPrf.ghostRightAnim = GreenDownRightIdleGhostAnimation;
   %charPrf.ghostLeftAnim = GreenDownleftIdleGhostAnimation;
   
   CharacterPrfs.add(%charPrf);
}

if(!isObject(RedJewPrf))
{
   %charPrf = new SimObject(RedJewPrf);
   
   ////BODY////
   //Idle Animations
   //%charPrf.upAnim
   %charPrf.upRightAnim = RedUpRightAnimation;
   //%charPrf.rightAnim
   %charPrf.downRightAnim = RedDownRightAnimation;
   //%charPrf.downAnim
   %charPrf.downLeftAnim = RedDownleftAnimation;
   //%charPrf.leftAnim
   %charPrf.upLeftAnim = RedUpleftAnimation;
   
   //%charPrf.idleUpAnim
   %charPrf.idleUpRightAnim = RedUpRightIdleAnimation;
   //%charPrf.idleRightAnim
   %charPrf.idleDownRightAnim = RedDownRightIdleAnimation;
   //%charPrf.idleDownAnim
   %charPrf.idleDownLeftAnim = RedDownleftIdleAnimation;
   //%charPrf.idleLeftAnim
   %charPrf.idleUpLeftAnim = RedUpleftIdleAnimation;
   
   ////ACTIONS////
   %charPrf.prayerAnim = RedPrayAnimation;
   //%charPrf.supriseAnim
   
   ////GHOST////
   %charPrf.ghostRightAnim = RedDownRightIdleGhostAnimation;
   %charPrf.ghostLeftAnim = RedDownleftIdleGhostAnimation;
   
   CharacterPrfs.add(%charPrf);
}

/////////////////////////////////////
// **prf_blessing.cs**
//   -Blessing profiles
//
//By Bryant Cannon
//10 February 2009
//////////////////////////////////////

//DESIGN NOTE:
//Each blessing is "responsible" for cancelling the walk
// cycle, making the character "busy", and reinstating the
// walk cycle with endAction

$blessings = new SimSet(BlessingSet);

/////SPECIAL////////
//Forgive Blessing; Not always in set
if(!isObject(Forgive))
{
   $forgive = new SimObject(Forgive);
   
   $forgive.actName = "Forgiveness";
   $forgive.imagePointer = Prayer_Hands_SpriteImageMap;
}

function Forgive::bless(%this,%charBhv)
{
   echo("Forgiven...");
   %charBhv.shamed = false;
   %charBhv.owner.saved = true;
   %charBhv.owner.prayedForgiveness = false;
   BlessingSet.remove($forgive);
   MasterObject.hideForgiveBubble(%charBhv);
   %h = newStaticSprite("halo",haloImageMap,0,0,1,true,false,3,3);
   %h.setLayer(1);
   %h.mount(%charBhv.owner,0,-1,0);
}

//Money
if(!isObject(MoneyBless))
{
   %bless = new SimObject(MoneyBless);
   
   %bless.actName = "Money";
   %bless.imagePointer = Money_Nero_Coin_SpriteImageMap;
   
   BlessingSet.add(%bless);
}

function MoneyBless::bless(%this,%charBhv)
{
   %charBhv.beginAction();
   //%charBhv.owner.setImageMap(CloudAngryAniImageMap);
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   
   %st = -11;
   %dn = 9;
   %sz = 2;
   
   //Create money sprites
   newStaticSprite("m1",Money_Nero_Coin_SpriteImageMap,%x-1.5,%y+%st,0,true,false,%sz,%sz);
   newStaticSprite("m2",Money_Nero_Coin_SpriteImageMap,%x+1.2,%y+%st,0,true,false,%sz,%sz);
   newStaticSprite("m3",Money_Nero_Coin_SpriteImageMap,%x-1.2,%y+%st,0,true,false,%sz,%sz);
   newStaticSprite("m4",Money_Nero_Coin_SpriteImageMap,%x+0.8,%y+%st,0,true,false,%sz,%sz);
   newStaticSprite("m5",Money_Nero_Coin_SpriteImageMap,%x-0.8,%y+%st,0,true,false,%sz,%sz);
   newStaticSprite("m6",Money_Nero_Coin_SpriteImageMap,%x+0.4,%y+%st,0,true,false,%sz,%sz);
   
   //Schedule to fall
   schedule(200,0,moveObject,m1,0,%dn,700,false);
   schedule(400,0,moveObject,m2,0,%dn,700,false);
   schedule(600,0,moveObject,m3,0,%dn,700,false);
   schedule(700,0,moveObject,m4,0,%dn,700,false);
   schedule(800,0,moveObject,m5,0,%dn,700,false);
   schedule(1000,0,moveObject,m6,0,%dn,700,false);
   
   //Schedule to fade in
   schedule(200,0,fadeAlpha,m1,100,1.0);
   schedule(400,0,fadeAlpha,m2,100,1.0);
   schedule(600,0,fadeAlpha,m3,100,1.0);
   schedule(700,0,fadeAlpha,m4,100,1.0);
   schedule(800,0,fadeAlpha,m5,100,1.0);
   schedule(1000,0,fadeAlpha,m6,100,1.0);
   
   //Schedule to fade out
   schedule(600,0,fadeAlpha,m1,300,0.0);
   schedule(800,0,fadeAlpha,m2,300,0.0);
   schedule(1000,0,fadeAlpha,m3,300,0.0);
   schedule(1200,0,fadeAlpha,m4,300,0.0);
   schedule(1400,0,fadeAlpha,m5,300,0.0);
   schedule(1600,0,fadeAlpha,m6,300,0.0);
   //Schedule sounds
   schedule(600,0,alxPlay,MoneySound);
   schedule(800,0,alxPlay,MoneySound);
   schedule(1000,0,alxPlay,MoneySound);
   schedule(1200,0,alxPlay,MoneySound);
   schedule(1400,0,alxPlay,MoneySound);
   schedule(1600,0,alxPlay,MoneySound);
   
   //Schedule to DELETE
   m1.schedule(2500,delete);
   m2.schedule(2500,delete);
   m3.schedule(2500,delete);
   m4.schedule(2500,delete);
   m5.schedule(2500,delete);
   m6.schedule(2500,delete);
   
   %charBhv.schedule(1400,endAction);
}

//Affection
if(!isObject(AffectionBless))
{
   %bless = new SimObject(AffectionBless);
   
   %bless.actName = "Affection";
   %bless.imagePointer = Companionship_SpriteImageMap;
   
   //BlessingSet.add(%bless);
}

function AffectionBless::bless(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudAngryAniImageMap);
   
   //Create Sprite
   %aff = newStaticSprite("aff",Companionship_SpriteImageMap,%x,%y,0.0,true,false,10,10);
   
   //Fade in and out
   fadeAlpha(%aff,500,0.9);
   schedule(3000,0,fadeAlpha,%aff,500,0.0);
   
   //Enda action
   %charBhv.schedule(3300,endAction);
   
   %aff.schedule(3500,delete);
}

//Strength
if(!isObject(StrengthBless))
{
   %bless = new SimObject(StrengthBless);
   
   %bless.actName = "Strength";
   %bless.imagePointer = Flex_Muscle_SpriteImageMap;
   
   BlessingSet.add(%bless);
}

function StrengthBless::bless(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudAngryAniImageMap);
   
   //Create arm sprites
   %arm1 = newStaticSprite("arm1",Flex_Muscle_SpriteImageMap,%x+2.5,%y-1.0,0,true,false,3,3);
   %arm2 = newStaticSprite("arm2",Flex_Muscle_SpriteImageMap,%x-2.5,%y-1.0,0,true,false,3,3);
   %arm2.flipX = true;
   
   //Fade in
   fadeAlpha(%arm1,400,0.8);
   fadeAlpha(%arm2,400,0.8);

   //Get bigger
   schedule(1400,0,scaleObject,%arm1,7,7,500,true);
   schedule(1400,0,scaleObject,%arm2,7,7,500,true);
   schedule(1400,0,moveObject,%arm1,2.2,0,500,false);
   schedule(1400,0,moveObject,%arm2,-2.2,0,500,false);
   
   schedule(2800,0,fadeAlpha,%arm1,500,0.0);
   schedule(2800,0,fadeAlpha,%arm2,500,0.0);
   
   //End action
   %charBhv.schedule(2500,endAction);
}

/////////////////////////////////////
// **yearTimer.cs**
//   -Provides timer for years passing
//
//By Bryant Cannon
//15 February 2009
//////////////////////////////////////

$MONTH_TIME = 20*1000;

if (!isObject(YearTimer))
{
   $yearTimer = new t2dSceneObject(YearTimer);
   
   $yearTimer.month = 1;
   $yearTimer.year = 25;
   $yearTimer.enableUpdateCallback();
   
}

function YearTimer::onUpdate(%this)
{
   MonthCtrl.setText(%this.getMonth());
   YearCtrl.setText(%this.year);
}

function YearTimer::progressTimer(%this)
{
   //Incriment month
   if(%this.month<12) {
      %this.month++;
   } else {
      %this.month = 1;
      %this.year++;
   }
   
   //Start timer again
   if (isEventPending(%this.timer)){
      cancel(%this.timer);
   }
   %this.timer = %this.schedule($MONTH_TIME,progressTimer);
}

function YearTimer::resetTimer(%this,%year)
{
   %this.month = 1;
   %this.year = %year;
   if (isEventPending(%this.timer)){
      cancel(%this.timer);
   }
   %this.timer = %this.schedule($MONTH_TIME,progressTimer);
}

function YearTimer::getMonth(%this)
{
   switch(%this.month)
   {
   case 1:
      return "January";
   case 2:
      return "February";
   case 3:
      return "March";
   case 4:
      return "April";
   case 5:
      return "May";
   case 6:
      return "June";
   case 7:
      return "July";
   case 8:
      return "August";
   case 9:
      return "September";
   case 10:
      return "October";
   case 11:
      return "November";
   case 12:
      return "December";
   }
   return "ERROR";
}

function YearTimer::getDay()
{
   %t = $MONTH_TIME - getEventTimeLeft(%this.timer);
   %day = mFloor((%t/$MONTH_TIME)*30);
   return %day;
}

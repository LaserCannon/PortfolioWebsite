/////////////////////////////////////
// **audioProfiles.cs**
//   -Audio profiles to play
//
//By Bryant Cannon
//15 February 2009
//////////////////////////////////////

new AudioDescription(AudioNonLooping)
{
   volume = 1.0;
   isLooping= false;
   is3D = false;
   type = $GuiAudioType;
};

new AudioDescription(AudioLooping)
{
   volume = 1.0;
   isLooping= true;
   is3D = false;
   type = $GuiAudioType;
};

new AudioDescription(MusicLooping)
{
   volume = 0.85;
   isLooping = true;
   is3D = false;
   type = $musicAudioType;
};


////////////////
// MUSIC
////////////////

new AudioProfile(biblicalMusic)
{
   filename = "~/data/audio/FLoGBiblicalMusic.ogg";
   description = "MusicLooping";
   preload = true;
};


////////////////
// SOUND
////////////////

new AudioProfile(churchBellSound)
{
   filename = "~/data/audio/church bells.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(rainLightSound)
{
   filename = "~/data/audio/rain light.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(sicknessSound)
{
   filename = "~/data/audio/SICKNESS 2.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(MoneySound)
{
   filename = "~/data/audio/FTLOG riches short.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(MenuLoSound)
{
   filename = "~/data/audio/FTLOG menu dooip lo.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(MenuLoReverseSound)
{
   filename = "~/data/audio/FTLOG menu dooip lo reverse.ogg";
   description = "AudioNonLooping";
   preload = true;
};

new AudioProfile(DreamSound)
{
   filename = "~/data/audio/FTLOG dream short2.ogg";
   description = "AudioNonLooping";
   preload = true;
};


/*datablock AudioProfile(biblicalMusic)
{
   filename = "~/data/audio/FLoGBiblicalMusic.ogg";
   description = "Music for Biblical level";
   preload = true;
};*/

///////////////////////////////////////
// **master.cs**
//   -MasterObject takes care of game-level
//    processing
//
//By Bryant Cannon
//4 February 2009
//////////////////////////////////////


$FADE_TIME = 200;

//Initialize buttons
exec("./buttons.cs");
//Initialize HUD
exec("./hud.cs");

//***MasterObject***

if(!isObject(MasterObject))
{
   $master = new SimObject(MasterObject);
}

function MasterObject::initButtons(%this)
{
   //Make sure buttons exist
   if(!isObject(BlessBtn))
   {
      $btn[0] = new t2dStaticSprite(BlessBtn);
      BlessBtn.buttons = new SimSet();
   }
   if(!isObject(SignBtn))
   {
      $btn[1] = new t2dStaticSprite(SignBtn);
      SignBtn.buttons = new SimSet();
   }
   if(!isObject(SmiteBtn))
   {
      $btn[2] = new t2dStaticSprite(SmiteBtn);
      SmiteBtn.buttons = new SimSet();
   }
   
   //Initialize interface buttons
   /////Bless Button/////
   BlessBtn.addToScene(sceneWindow2D.getSceneGraph());
   BlessBtn.setUseMouseEvents(false);
   BlessBtn.enableUpdateCallback();
   BlessBtn.setVisible(false);
   BlessBtn.setImageMap(BlessButtonRockImageMap);
   BlessBtn.setSize("10 5");
   BlessBtn.setLayer(1);

   /////Sign Button/////
   SignBtn.addToScene(sceneWindow2D.getSceneGraph());
   SignBtn.setUseMouseEvents(false);
   SignBtn.enableUpdateCallback();
   SignBtn.setVisible(false);
   SignBtn.setImageMap(SignButtonRockImageMap);
   SignBtn.setSize("10 5");
   SignBtn.setLayer(1);

   /////Smite Button/////
   SmiteBtn.addToScene(sceneWindow2D.getSceneGraph());
   SmiteBtn.setUseMouseEvents(false);
   SmiteBtn.enableUpdateCallback();
   SmiteBtn.setVisible(false);
   SmiteBtn.setImageMap(SmiteButtonRockImageMap);
   SmiteBtn.setSize("10 5");
   SmiteBtn.setLayer(1);
   
   //Light sprite (really a HUD thing... didnt want to make a whole new funtion)
   $light = newStaticSprite(SelectLight,charLightImageMap,0,0,0,1,0,7,11);
   $light.setLayer(7);
}

function MasterObject::initHUD(%this,%charBhv)
{
   //Make sure templates are in scene
   if (!sceneWindow2D.getSceneGraph().isMember(FaithTemplate)) {
      FaithTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   if (!sceneWindow2D.getSceneGraph().isMember(LoveTemplate)) {
      LoveTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   if (!sceneWindow2D.getSceneGraph().isMember(AngerTemplate)) {
      AngerTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   if (!sceneWindow2D.getSceneGraph().isMember(ShameTemplate)) {
      ShameTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   if (!sceneWindow2D.getSceneGraph().isMember(PrayerBubbleTemplate)) {
      PrayerBubbleTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   //if (!sceneWindow2D.getSceneGraph().isMember(InteractiveBubbleTemplate)) {
     // InteractiveBubbleTemplate.addToScene(sceneWindow2D.getSceneGraph());
   //}
   if (!sceneWindow2D.getSceneGraph().isMember(ActionButtonTemplate)) {
      ActionButtonTemplate.addToScene(sceneWindow2D.getSceneGraph());
   }
   if (!sceneWindow2D.getSceneGraph().isMember(YearTimer)) {
      YearTimer.addToScene(sceneWindow2D.getSceneGraph());
   }
   
   //Faith Meter
   %charBhv.faithMeter = FaithTemplate.clone(false);
   %charBhv.faithMeter.char = %charBhv.owner;
   %charBhv.faithMeter.setName(%charBhv.name @ "Faith");
   %charBhv.faithMeter.schedule(200,mount,%charBhv.owner,getLocalX(%charBhv.owner,-1.8),getLocalY(%charBhv.owner,-6),0,false,true,true,false);
   %charBhv.faithMeter.setVisible(true);
   %newbehave = FaithBehave.createInstance();
   %charBhv.faithMeter.addBehavior(%newbehave);
   %newbehave.obj = %charBhv.faithMeter;        //Because %this.owner doesn't work right
   %charBhv.faithMeter.enableUpdateCallback();
   //Love Meter
   %charBhv.loveMeter = LoveTemplate.clone(false);
   %charBhv.loveMeter.char = %charBhv.owner;
   %charBhv.loveMeter.setName(%charBhv.name @ "Love");
   %charBhv.loveMeter.schedule(200,mount,%charBhv.owner,getLocalX(%charBhv.owner,1.8),getLocalY(%charBhv.owner,-6),0,false,true,true,false);
   %charBhv.loveMeter.setVisible(true);
   %newbehave2 = LoveBehave.createInstance();
   %charBhv.loveMeter.addBehavior(%newbehave2);
   %newbehave2.obj = %charBhv.loveMeter;
   %charBhv.loveMeter.enableUpdateCallback();
   //Anger Meter
   %charBhv.angerMeter = AngerTemplate.clone(false);
   %charBhv.angerMeter.char = %charBhv.owner;
   %charBhv.angerMeter.setName(%charBhv.name @ "Anger");
   %charBhv.angerMeter.schedule(200,mount,%charBhv.owner,0,-0.62,0,false,true,true,false);
   %charBhv.angerMeter.setVisible(true);
   %newbehaveang = AngerBehave.createInstance();
   %charBhv.angerMeter.addBehavior(%newbehaveang);
   %newbehaveang.obj = %charBhv.angerMeter;        //Because %this.owner doesn't work right
   %charBhv.angerMeter.enableUpdateCallback();
   
   //Shamed Indicator
   %charBhv.shameSprite = ShameTemplate.clone(true);
   %charBhv.shameSprite.char = %charBhv.owner;
   %charBhv.shameSprite.setName(%charBhv.name @ "Shame");
   %charBhv.shameSprite.schedule(200,mount,%charBhv.owner,0,getLocalY(%charBhv.owner,-6.5),0,false,true,true,false);
   %charBhv.shameSprite.setVisible(false);
   %newbehave3 = ShameBehave.createInstance();
   %charBhv.shameSprite.addBehavior(%newbehave3);
   %newbehave3.obj = %charBhv.shameSprite;
   %charBhv.shameSprite.enableUpdateCallback();
   
   //Prayer bubbles
   for(%i=0;%i<3;%i++)
   {
      //Display bubbles
      %charBhv.bubbleSprite[%i] = PrayerBubbleTemplate.clone(true);
      %charBhv.bubbleSprite[%i].char = %charBhv.owner;
      %charBhv.bubbleSprite[%i].setName(%charBhv.name @ "Bubble" @ %i);
      %charBhv.bubbleSprite[%i].setVisible(true);
      %charBhv.bubbleSprite[%i].setBlendAlpha(0);
      %newbehave4 = BubbleBehave.createInstance();
      %charBhv.bubbleSprite[%i].addBehavior(%newbehave4);
      %newbehave4.obj = %charBhv.bubbleSprite[%i];
      %charBhv.bubbleSprite[%i].enableUpdateCallback();
      //Display pictures in bubbles
      %charBhv.bubbleSprite[%i].img = new t2dStaticSprite();
      %img = %charBhv.bubbleSprite[%i].img;
       if(isObject(%charBhv.owner.desires[%i])) {
         %img.setImageMap(%charBhv.owner.desires[%i].imagePointer);
      }
      %img.addToScene(sceneWindow2D.getSceneGraph());
      %img.setUseMouseEvents(false);
      %img.setSize("3 3");
      %img.setLayer(1);
      %img.setVisible(false);
      %img.setBlendAlpha(0);
   }
   /*/Interactive bubble
   %charBhv.interactiveBubble = InteractiveBubbleTemplate.clone(true);
   %charBhv.interactiveBubble.char = %charBhv.owner;
   %charBhv.interactiveBubble.setName(%charBhv.name @ "IntBubble");
   %charBhv.interactiveBubble.setVisible(false);
   %newbehave6 = InteractiveBubbleBehave.createInstance();
   %charBhv.interactiveBubble.addBehavior(%newbehave6);
   %newbehave6.obj = %charBhv.interactiveBubble;
   %charBhv.interactiveBubble.enableUpdateCallback();
   %charBhv.interactiveBubble.schedule(200,mount,%charBhv.owner,1,-1,0,false,true,true,false);*/
   //Forgive bubble
   %charBhv.forgiveSprite = PrayerBubbleTemplate.clone(true);
   %charBhv.forgiveSprite.char = %charBhv.owner;
   %charBhv.forgiveSprite.setName(%charBhv.name @ "Forgive");
   %charBhv.forgiveSprite.setVisible(true);
   %charBhv.forgiveSprite.setBlendAlpha(0);
   %newbehave5 = BubbleBehave.createInstance();
   %charBhv.forgiveSprite.addBehavior(%newbehave5);
   %newbehave5.obj = %charBhv.forgiveSprite;
   %charBhv.forgiveSprite.enableUpdateCallback();
   //Display picture
   %charBhv.forgiveSprite.img = new t2dStaticSprite();
   %img = %charBhv.forgiveSprite.img;
   %img.setImageMap(Faith_Icon_UsableImageMap);
   %img.addToScene(sceneWindow2D.getSceneGraph());
   %img.setUseMouseEvents(false);
   %img.setSize("3 3");
   %img.setLayer(1);
   %img.setVisible(false);
}

function MasterObject::hideHUD(%this,%charBhv)
{
   %charBhv.loveMeter.setVisible(false);
   %charBhv.faithMeter.setVisible(false);
   %charBhv.shameSprite.setVisible(false);
}

function MasterObject::displayPrayerBubbles(%this,%charBhv)
{
   //Update image maps
   for(%i=0;%i<3;%i++)
   {
      if(isObject(%charBhv.owner.desires[%i]))
      {
         %charBhv.bubbleSprite[%i].img.mount(%charBhv.bubbleSprite[%i],0,-0.2,0,true,true,true,true);
         %charBhv.bubbleSprite[%i].img.setImageMap(%charBhv.owner.desires[%i].imagePointer);
      }
   }
   
   //Correct size
   for(%i=0;%i<3;%i++)
   {
      scaleObject(%charBhv.bubbleSprite[%i],6,6,$FADE_TIME,true);
      scaleObject(%charBhv.bubbleSprite[%i].img,3,3,$FADE_TIME,true);
   }
   scaleObject(%charBhv.forgiveSprite,6,6,$FADE_TIME,true);
   scaleObject(%charBhv.forgiveSprite.img,3,3,$FADE_TIME,true);
   
   //Display each bubble
   if(%charBhv.getNumPrayedFor()==0)
   { 
      for(%i=0;%i<3;%i++) {
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(%i,0)],$FADE_TIME,0);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(%i,0)].img,$FADE_TIME,0);
      }
      return;
   }
   
   if(%charBhv.getNumPrayedFor()==1 || %charBhv.getNumPrayedFor()==3)
   {
      %charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)].mount(%charBhv.owner,0,-2,0,false,true,false,false);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)],$FADE_TIME,1);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)].img,$FADE_TIME,1);
      if(%charBhv.getNumPrayedFor()==3)
      {
         %charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)].mount(%charBhv.owner,1.5,-1.7,0,false,true,false,false);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)],$FADE_TIME,1);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)].img,$FADE_TIME,1);
         %charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)].mount(%charBhv.owner,-1.5,-1.7,0,false,true,false,false);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)],$FADE_TIME,1);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)].img,$FADE_TIME,1);
      }
      else
      {
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)],$FADE_TIME,0);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)].img,$FADE_TIME,0);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)],$FADE_TIME,0);
         fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)].img,$FADE_TIME,0);
      }
   }
   else if(%charBhv.getNumPrayedFor()==2)
   {
      %charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)].mount(%charBhv.owner,1,-2,0,false,true,false,false);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)],$FADE_TIME,1);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(0,0)].img,$FADE_TIME,1);
      %charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)].mount(%charBhv.owner,-1,-2,0,false,true,false,false);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)],$FADE_TIME,1);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(1,0)].img,$FADE_TIME,1);
      
      //Fade third bubble
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)],$FADE_TIME,0);
      fadeAlpha(%charBhv.bubbleSprite[%charBhv.getDesirePrayed(2,0)].img,$FADE_TIME,0);
   }
}

function MasterObject::displayForgiveBubble(%this,%charBhv)
{
   //Make sure image is mounted to bubble
   %charBhv.forgiveSprite.img.mount(%charBhv.forgiveSprite,0,-0.2,0,true,true,true,true);
   
   //Mount bubble to character and make visible
   %charBhv.forgiveSprite.mount(%charBhv.owner,0,1.5,0,false,true,false,false);
   fadeAlpha(%charBhv.forgiveSprite,$FADE_TIME,1);
   fadeAlpha(%charBhv.forgiveSprite.img,$FADE_TIME,1);
}

function MasterObject::hideForgiveBubble(%this,%charBhv)
{
   fadeAlpha(%charBhv.forgiveSprite,$FADE_TIME,0);
   fadeAlpha(%charBhv.forgiveSprite.img,$FADE_TIME,0);
}

function MasterObject::hidePrayerBubbles(%this,%charBhv)
{
   for(%i=0;%i<3;%i++)
   {
      fadeAlpha(%charBhv.bubbleSprite[%i],$FADE_TIME,0);
      fadeAlpha(%charBhv.bubbleSprite[%i].img,$FADE_TIME,0);
   }
   fadeAlpha(%charBhv.forgiveSprite,$FADE_TIME,0);
   fadeAlpha(%charBhv.forgiveSprite.img,$FADE_TIME,0);
}

function MasterObject::shrinkPrayerBubbles(%this,%charBhv)
{
   for(%i=0;%i<3;%i++)
   {
      scaleObject(%charBhv.bubbleSprite[%i],3,3,$FADE_TIME,true);
      scaleObject(%charBhv.bubbleSprite[%i].img,1.5,1.5,$FADE_TIME,true);
   }
   scaleObject(%charBhv.forgiveSprite,3,3,$FADE_TIME,true);
   scaleObject(%charBhv.forgiveSprite.img,1.5,1.5,$FADE_TIME,true);
}


function MasterObject::displayOptions(%this)
{
   //First, hide the options from any previous use
   %this.hideOptions();
   %this.optionsUp = true;
   
   //Make sure character is an object
   if (!isObject($charSelect)) {
      error("$charSelect does not exist");
      return;
   }
   //Mount buttons to character
   BlessBtn.mount($charSelect,getLocalX($charSelect,0),getLocalY($charSelect,8),0,false,true,false,false);
   SignBtn.mount($charSelect,getLocalX($charSelect,8),getLocalY($charSelect,3),0,false,true,false,false);
   SmiteBtn.mount($charSelect,getLocalX($charSelect,-8),getLocalY($charSelect,3),0,false,true,false,false);
   
   //Make buttons FADE TO visible and become clickable
   BlessBtn.setBlendColor(1,1,1,0);
   SignBtn.setBlendColor(1,1,1,0);
   SmiteBtn.setBlendColor(1,1,1,0);
   BlessBtn.setVisible(true);
   SignBtn.setVisible(true);
   SmiteBtn.setVisible(true);
   fadeAlpha(BlessBtn,100,1.0);
   fadeAlpha(SignBtn,100,1.0);
   fadeAlpha(SmiteBtn,100,1.0);
   BlessBtn.setUseMouseEvents(true);
   SignBtn.setUseMouseEvents(true);
   SmiteBtn.setUseMouseEvents(true);
}

function MasterObject::hideOptions(%this)
{
   %this.optionsUp = false;
   //Erase Current Button record
   $CUR_BTN_OUT = "NONE";   
   
   //Hide Action buttons
   fadeAllBut("NONE");
   
   //Erase help message
   HelpCtrl.setText(" ");
   
   //Get rid of forgiveness button if there
   if(BlessingSet.isMember(Forgive))
   {
      BlessingSet.remove($forgive);
   }
   
   //Hide Category buttons and disable clicks
   //BlessBtn.setVisible(false);
   //SignBtn.setVisible(false);
   //SmiteBtn.setVisible(false);
   fadeAlpha(BlessBtn,100,0.0);
   fadeAlpha(SmiteBtn,100,0.0);
   fadeAlpha(SignBtn,100,0.0);
   BlessBtn.setUseMouseEvents(false);
   SignBtn.setUseMouseEvents(false);
   SmiteBtn.setUseMouseEvents(false);
}

function MasterObject::displayName(%this,%charBhv)
{
   if(!isObject(%charBhv.nm)) {
      %charBhv.nm = newText("aName",%charBhv.charName,"Altenglisch MF",2,0,0,0,1);
      %charBhv.nm.mount(%charBhv.owner,0,getLocalY(%charBhv.owner,4.5));
   }
}

function MasterObject::hideName(%this,%charBhv)
{
   if(isObject(%charBhv.nm)) {
      %charBhv.nm.safeDelete();
   }
}

function MasterObject::displayLight(%this,%charBhv)
{
   $light.mount(%charBhv.owner);
   fadeAlpha($light,90,0.8);
}

function MasterObject::hideLight()
{
   fadeAlpha($light,90,0.0);
}


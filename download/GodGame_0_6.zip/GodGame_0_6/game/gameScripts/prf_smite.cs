/////////////////////////////////////
// **prf_smite.cs**
//   -Smite profiles
//
//By Bryant Cannon
//15 February 2009
//////////////////////////////////////

//DESIGN NOTE:
//Each smite is "responsible" for cancelling the walk
// cycle, making the character "busy", and reinstating the
// walk cycle with endAction

$smites = new SimSet(SmiteSet);

//Illness
if(!isObject(IllnessSmite))
{
   %smite = new SimObject(IllnessSmite);
   
   %smite.actName = "Illness";
   %smite.imagePointer = Smite_SicknessImageMap;
   
   SmiteSet.add(%smite);
}

function IllnessSmite::smite(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudTiredAniImageMap);
   
   $sick = alxPlay(sicknessSound);
   
   //Fade character
   fadeColor(%charBhv.owner,1000,0.6,1.0,0.6,1.0);
   schedule(3000,0,fadeColor,%charBhv.owner,500,1.0,1.0,1.0,1.0);
   %charBhv.schedule(3200,endAction);
}

//Lightning
if(!isObject(LightningSmite))
{
   %smite = new SimObject(LightningSmite);
   
   %smite.actName = "Lightning";
   %smite.imagePointer = Sign_Smite_LightningImageMap;
   
   SmiteSet.add(%smite);
}

function LightningSmite::smite(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudTiredAniImageMap);
   
   //Lighting strike
   %ltng = newStaticSprite(ltng,Sign_Smite_LightningImageMap,%x,%y-20,1,true,false,4,1);
   scaleObject(%ltng,4,20,400,true);
   moveObject(%ltng,0,10,400,false);
   schedule(600,0,fadeAlpha,%ltng,150,0.2);
   schedule(800,0,fadeAlpha,%ltng,150,1.0);
   schedule(1000,0,fadeAlpha,%ltng,150,0.2);
   schedule(1200,0,fadeAlpha,%ltng,150,1.0);
   schedule(1400,0,fadeAlpha,%ltng,150,0.2);
   schedule(1600,0,fadeAlpha,%ltng,150,1.0);
   schedule(1800,0,fadeAlpha,%ltng,150,0.0);
   
   %charBhv.schedule(2000,endAction);
   
   %ltng.schedule(2500,delete);
}

//Lightning
if(!isObject(TornadoSmite))
{
   %smite = new SimObject(TornadoSmite);
   
   %smite.actName = "Tornado";
   %smite.imagePointer = Smite_TornadoImageMap;
   
   //SmiteSet.add(%smite);
}

function TornadoSmite::smite(%this,%charBhv)
{
   %charBhv.beginAction();
   %x = %charBhv.owner.getPositionX();
   %y = %charBhv.owner.getPositionY();
   //%charBhv.owner.setImageMap(CloudTiredAniImageMap);
   
   %trnd = newStaticSprite(trnd,Smite_TornadoImageMap,%x+5,%y+5,1,true,false,-1,-1);
   moveObject(%trnd,-10,0,290,false);
   schedule(300,0,moveObject,%trnd,0,-10,290,false);
   schedule(600,0,moveObject,%trnd,10,0,290,false);
   schedule(900,0,moveObject,%trnd,0,10,290,false);
   schedule(1200,0,moveObject,%trnd,-10,0,290,false);
   schedule(1500,0,moveObject,%trnd,0,-10,290,false);
   schedule(1800,0,moveObject,%trnd,10,0,290,false);
   schedule(2100,0,moveObject,%trnd,0,10,290,false);
   schedule(2100,0,fadeAlpha,%trnd,290,0.0);
   
   %charBhv.schedule(2500,endAction);
   
   %trnd.schedule(2600,delete);
}

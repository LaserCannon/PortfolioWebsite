//---------------------------------------------------------------------------------------------
// Torque Game Builder
// Copyright (C) GarageGames.com, Inc.
//---------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
// startGame
// All game logic should be set up here. This will be called by the level builder when you
// select "Run Game" or by the startup process of your game to load the first level.
//---------------------------------------------------------------------------------------------
function startGame(%level)
{
   //Set resolution
   setScreenMode(1280,800,32,true);
   
   Canvas.setCursor(DefaultCursor);
   
   new ActionMap(moveMap);
   moveMap.push();
   
   $enableDirectInput = true;
   activateDirectInput();
   enableJoystick();

   //Load level
   levelProgress(%level,true);
}

//---------------------------------------------------------------------------------------------
// endGame
// Game cleanup should be done here.
//---------------------------------------------------------------------------------------------
function endGame()
{
   sceneWindow2D.endLevel();
   moveMap.pop();
   moveMap.delete();
}

function levelProgress(%level,%isMenu)
{
   sceneWindow2D.endLevel();
   splashSceneWindow2D.endLevel();
   
   $charSelect = "NULL";
   
   //Initialize objects and load level
   if(%isMenu) {
      Canvas.setContent(splashScreenGui);
      splashSceneWindow2D.loadLevel(%level);
   } else {
      Canvas.setContent(gameScreenGui);
      sceneWindow2D.loadLevel(%level);
      $bgm = alxPlay(biblicalMusic);
   }
   MasterObject.initButtons();
   YearTimer.resetTimer(25);

   /*%temp = new t2dStaticSprite(tmp);
   %bv = tutorialBhvTemp.createInstance();
   %temp.addBehavior(%bv);
   %temp.setLayer(0);
   %temp.addToScene(sceneWindow2D.getSceneGraph());*/
}

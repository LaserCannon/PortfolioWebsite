///////////////////////////////////////
// **SceneWindow.cs**
//   -Background behaviors and SceneWindow functions
//
//By Bryant Cannon
//8 February 2009
//////////////////////////////////////


function sceneWindow2D::onRightMouseDown(%this)
{
   if ($charSelect !$= "NULL")
   {
      MasterObject.hideOptions();
      if(!%this.obj.char.charBhv.praying) {
         MasterObject.shrinkPrayerBubbles($charSelect.charBhv);
      }
      if(isObject($charSelect) && $charSelect.charBhv.isFree() && $charSelect.getID()!=%this.owner)
      {
         MasterObject.hideName($charSelect.charBhv);
         MasterObject.hideLight();
         $charSelect.charBhv.endAction();
         //Make a sound!
         $menu = alxPlay(MenuLoReverseSound);
      }
      if($charSelect.free && !$charSelect.errand)
      {
         $charSelect = "NULL";
      }
   }
}

function hideAndReset()
{
   if ($charSelect !$= "NULL" && $clickedOnButton==false)
   {
      $charSelect = "NULL";
      MasterObject.hideOptions();
   }
   else if ($clickedOnButton==true)
   {
      $clickedOnButton = false;
   }
}
